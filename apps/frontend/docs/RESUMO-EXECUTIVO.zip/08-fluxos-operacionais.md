# 08 — Fluxos Operacionais

## Objetivo deste documento

Descrever os fluxos completos de cada módulo do sistema, do ponto de vista do usuário e da tecnologia, com todos os passos, atores e pontos de decisão.

---

## Fluxo 1 — Criação de planejamento e levantamento por DRONE

### Atores
- **Gestor/Supervisor** — cria o planejamento
- **Piloto** — opera o drone (sistema Python externo)
- **Operador** — atende os focos identificados

### Passos

```
1. GESTOR acessa /admin/planejamentos
2. Clica em "Novo Planejamento"
3. Seleciona: tipo=DRONE, região, data
4. Sistema verifica quota de voos via api.quotas.verificar
   → Se quota esgotada: alerta e bloqueia
   → Se ok: planejamento criado
5. PILOTO abre sistema Python (módulo Sentinella)
6. Executa voo na região definida
7. Drone captura imagens com GPS embutido (EXIF)
8. Pipeline Python:
   a. ExifTool extrai lat/lng de cada imagem
   b. YOLO analisa cada imagem
   c. Para cada detecção:
      - Upload imagem → Edge Function cloudinary-upload-image
      - Obtém secure_url + public_id
      - Chama RPC criar_levantamento_item_manual com:
        {planejamento_id, tipo_entrada='DRONE', score_final, risco, prioridade, image_url, ...}
9. RPC no banco:
   a. Verifica planejamento ativo
   b. Cria/reutiliza levantamento do dia
   c. Insere levantamento_item
   d. Trigger: cria sla_operacional (status=pendente)
   e. Trigger: verifica recorrência (eleva prioridade se recorrente)
10. GESTOR vê novos itens no dashboard e mapa
11. GESTOR pode acionar "Triagem IA" → Edge Function triagem-ia-pos-voo
    a. Agrupa itens por grade 0.001°
    b. Filtra possíveis falsos positivos
    c. Claude Haiku gera sumário executivo
    d. Resultado em levantamento_analise_ia
12. GESTOR atribui itens a operadores (ou operador pega voluntariamente)
```

---

## Fluxo 2 — Atendimento de foco pelo OPERADOR

### Atores
- **Operador** — atende o foco no campo

### Passos

```
1. OPERADOR acessa /operador (SLA Operacional) ou /operador/mapa
2. Visualiza itens pendentes ordenados por SLA restante
   → Cor: verde (ok) | âmbar (alerta < 20%) | vermelho (vencido)
3. Clica em item → ItemDetailPanel abre
   → Vê: endereço, risco, score YOLO, imagem, SLA restante
   → Vê: banner de casos próximos (se houver casos notificados em 300m)
   → Vê: histórico de recorrência (se endereço repetido em 30 dias)
4. Clica "Iniciar Atendimento"
   → api.itens.updateAtendimento(id, { status: 'em_atendimento' })
   → sla_operacional.status → em_atendimento
   → Auditoria: levantamento_item_status_historico registra mudança
5. OPERADOR vai ao campo
6. No campo, clica "Registrar Checkin"
   → GPS capturado automaticamente
   → api.itens.registrarCheckin(id, { lat, lng, em })
7. OPERADOR resolve o foco (trata o depósito, elimina larvas, etc.)
8. Clica "Marcar como Resolvido"
   → Seleciona ação aplicada do catálogo de planos
   → api.itens.updateAtendimento(id, { status: 'resolvido', acao_aplicada })
   → Trigger fecha sla_operacional correspondente
   → Se passou do prazo: violado=true
9. OPERADOR pode adicionar evidência fotográfica
   → Upload via Edge Function upload-evidencia
   → URL gravada em levantamento_item_evidencias
```

---

## Fluxo 3 — Vistoria de campo pelo AGENTE

### Atores
- **Agente de campo** — visita domicílios

### Passos

```
1. AGENTE acessa /operador/inicio (ou /agente/hoje)
2. Visualiza stats do ciclo atual:
   → Imóveis pendentes, visitados, cobertura %
3. Seleciona tipo de atividade: Tratamento / Pesquisa / LIRAa / Ponto Estratégico
4. Acessa /operador/imoveis
5. Lista de imóveis com status colorido (vermelho=pendente, verde=visitado, âmbar=revisita)
6. Seleciona imóvel ou cadastra novo
7. Acessa /operador/vistoria/:imovelId

[Etapa 1 — Responsável]
8. GPS capturado automaticamente (timeout 8s)
9. Toggle "Conseguiu entrar?"
   → NÃO: fluxo VistoriaSemAcesso (motivo, calha visível, horário retorno, foto)
   → SIM: continua stepper

[Etapa 2 — Sintomas]
10. Toggles: febre, manchas, articulações, cabeça
11. Contador moradores com sintomas
    → Se > 0: banner "Caso suspeito"
    → Ao finalizar: trigger cria caso_notificado automaticamente

[Etapa 3 — Inspeção de Depósitos]
12. Para cada tipo A1, A2, B, C, D1, D2, E:
    → Qtd inspecionados + Qtd com focos (limitado a ≤ inspecionados)
13. Seção de calhas:
    → tem_calha? → posição, condição, foco visível

[Etapa 4 — Tratamento]
14. Para cada depósito com foco:
    → Qtd eliminados + toggle larvicida + quantidade larvicida

[Etapa 5 — Riscos]
15. Riscos sociais, sanitários, vetoriais (checkboxes)
16. Campo de observações livre
17. Clica "FINALIZAR"
    → Online: sequência de chamadas (create→depositos→sintomas→riscos→calhas→perfil_imovel)
    → Offline: enfileira operação save_vistoria no IndexedDB
18. Tela de sucesso com resumo
19. offlineQueue drena ao reconectar
```

---

## Fluxo 4 — Registro de caso notificado

### Atores
- **Notificador** — funcionário de UBS/hospital

### Passos

```
1. NOTIFICADOR acessa /notificador/registrar
2. Preenche formulário:
   → Doença (dengue | chikungunya | zika | suspeito)
   → Status (suspeito | confirmado)
   → Data início sintomas
   → Endereço do paciente (geocodificado — sem nome/CPF)
   → Unidade de saúde onde foi atendido
   → Observações
3. Aviso LGPD exibido: "Não informar nome ou CPF do paciente"
4. Submete → api.casosNotificados.create(payload)
5. INSERT em casos_notificados
6. Trigger trg_cruzar_caso_focos dispara:
   a. Busca levantamento_itens do mesmo cliente em 300m (haversine)
   b. Para cada foco próximo:
      → Insere em caso_foco_cruzamento
      → Eleva prioridade do item para "Crítico"
      → Atualiza payload do item com caso_id
   c. sla_operacional do item é recalculado com nova prioridade
7. GESTOR vê no AdminCasosNotificados novos casos
8. Se 3+ casos no mesmo bairro → botão "Criar Planejamento" aparece
9. OPERADOR vê banner no ItemDetailPanel: "X casos notificados em 300m"
```

---

## Fluxo 5 — SLA Operacional completo

### Atores
- **Sistema** — cria SLA automaticamente
- **Operador** — executa o atendimento
- **Admin/Supervisor** — monitora e escala

### Passos

```
1. Item inserido → trigger cria sla_operacional (status=pendente, prazo calculado)
2. Edge Function sla-marcar-vencidos roda a cada 15min:
   → Marca vencido qualquer SLA onde prazo_final < NOW()
3. Frontend useSlaAlerts.ts poll a cada 1min:
   → Chama marcar_slas_vencidos(cliente_id)
   → Busca SLAs urgentes/vencidos/escalados
   → Dispara toasts + notificações do navegador
4. Se SLA ≤ 1h restante:
   → Edge Function sla-push-critico envia Web Push ao operador
5. OPERADOR inicia atendimento → status=em_atendimento
6. OPERADOR conclui → operação fechada → trigger fecha SLA
   → Se antes do prazo: violado=false, concluido_em=now()
   → Se depois do prazo: violado=true, concluido_em=now()
7. ADMIN pode escalar SLA:
   → api.sla.escalar(id) → RPC escalar_sla_operacional
   → Preserva prioridade_original, eleva prioridade, recalcula prazo
8. ADMIN pode reabrir SLA concluído:
   → api.sla.reabrir(id) → status=pendente
9. Relatório semanal (Edge Function relatorio-semanal):
   → Toda segunda 8h UTC: email com resumo de SLAs e violações
```

---

## Fluxo 6 — Canal Cidadão

### Atores
- **Cidadão** — qualquer pessoa com o QR code

### Passos

```
1. Prefeitura gera QR code em /admin/canal-cidadao
2. QR code aponta para /denuncia/:slug/:bairroId
3. CIDADÃO escaneia QR com celular
4. Acessa página pública (sem login)
5. Preenche formulário:
   → Tipo de problema (criadouro, entulho, etc.)
   → Descrição
   → Foto (opcional)
   → Endereço (opcional)
6. Submete → RPC SECURITY DEFINER insere em canal_cidadao
   → Slug identifica a prefeitura sem expor o cliente_id
7. GESTOR vê denúncias em /admin/canal-cidadao
8. Denúncia pode virar um item de levantamento ou planejamento
```

---

## Fluxo 7 — Sync CNES

### Atores
- **Sistema** — automático via cron
- **Admin** — pode disparar manualmente

### Passos

```
1. Cron 03:00 UTC → Edge Function cnes-sync dispara
2. Para cada cliente com uf + ibge_municipio cadastrados:
   a. Verifica unidades_saude_sync_controle (evita dupla execução)
   b. Chama API CNES/DATASUS com código IBGE
   c. Para cada unidade retornada:
      → Insere ou atualiza em unidades_saude (por código CNES único)
      → Atualiza nome, telefone, tipo, endereço, status ativo
   d. Unidades do banco não presentes na API → ativo=false (soft delete)
      → EXCETO unidades com origem='manual' e sem código CNES
   e. Registra em sync_controle (totais) e sync_log (linha por linha)
   f. Retry 3x com backoff em caso de falha de rede
3. ADMIN pode disparar sync manual:
   → Botão em AdminUnidadesSaude
   → api.cnesSync.sincronizarManual(clienteId)
   → Edge Function em modo manual (apenas para aquele cliente)
4. Frontend polling 5s via useCnesSyncControle enquanto em_andamento=true
5. Resultado exibido: totais inseridos/atualizados/inativos
```

---

## Fluxo 8 — Relatório semanal automático

### Passos

```
1. Todo domingo à meia-noite (ou segunda 8h UTC): Edge Function relatorio-semanal
2. Para cada cliente ativo:
   a. Coleta dados da semana:
      → Itens abertos, resolvidos, violações SLA
      → Focos por risco (alto/médio/baixo)
      → Operações realizadas
      → Casos notificados
      → Bairros de maior risco
   b. Gera HTML de relatório
   c. Envia por email via Resend API para o supervisor/gestor cadastrado
3. Email contém link para o dashboard do sistema
```

---

## Fluxo 9 — Triagem IA pós-voo

### Passos

```
1. GESTOR acessa levantamento recém-processado
2. Clica "Analisar com IA"
3. Frontend chama api.analiseIa.triggerTriagem(levantamento_id)
4. Edge Function triagem-ia-pos-voo:
   a. Busca todos itens do levantamento
   b. Agrupa por grade geográfica (0.001° ≈ 100m)
   c. Filtra itens isolados com score baixo (possíveis falsos positivos)
   d. Para cada cluster significativo:
      → Monta contexto: quantidade, risco, coordenadas, scores
   e. Chama Claude Haiku com prompt estruturado
   f. Claude gera sumário em linguagem natural (pt-BR)
   g. Persiste em levantamento_analise_ia
5. Frontend exibe sumário no painel do levantamento
```

---

## Pontos de falha críticos nos fluxos

### Pipeline Python sem feedback ao sistema web

Se o voo processar mas o pipeline Python falhar silenciosamente, o gestor não sabe. Não há status de "processamento em andamento" ou "falhou" visível no sistema.

### Fila offline com sequência de operações

O `save_vistoria` enfileirado offline é uma sequência de 4+ chamadas. Se a rede cair no meio da drenagem, a vistoria pode ficar parcialmente gravada sem mecanismo de compensação.

### Trigger de cruzamento com múltiplos casos

Múltiplos casos próximos ao mesmo foco sobrescrevem o `payload` um ao outro. Apenas o último caso é referenciado no payload do item.

### Janela de 15 minutos no SLA vencido

SLA que venceu às 14:00 pode aparecer como "em dia" até a próxima execução da Edge Function às 14:15.

---

## Dúvidas em aberto

- No fluxo do agente: se a vistoria é salva offline e drenada depois, o ciclo calculado (baseado na data atual) é o da data offline ou da data de sincronização?
- O gestor tem algum mecanismo para saber que um voo foi concluído e o pipeline está processando?
- Existe notificação para o gestor quando a triagem IA é concluída?
