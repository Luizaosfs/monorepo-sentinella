# 03 — Backend

## Objetivo deste documento

Descrever o backend do Sentinella Web: como funciona, onde está a lógica, o que cada Edge Function faz, como os triggers operam, e onde estão os problemas.

---

## O que é o "backend" do Sentinella?

O Sentinella não tem um servidor Node/Express/NestJS tradicional. O backend é composto por:

1. **Supabase PostgreSQL** — banco de dados com lógica embutida (triggers, RPCs em PL/pgSQL)
2. **Supabase Edge Functions** — funções serverless em Deno/TypeScript
3. **api.ts no frontend** — camada intermediária que constrói queries e chama RPCs
4. **Pipeline Python externo** — processamento de drone, YOLO, pluviometria

---

## api.ts — A camada de serviço

### O que é

`src/services/api.ts` é o **único ponto de acesso ao Supabase** a partir do frontend. Nenhum componente de página deve importar `supabase` diretamente.

### Estrutura (namespaces)

```typescript
export const api = {
  levantamentos: { list, updatePlanejamento },
  itens: { listByLevantamento, listByCliente, listMapByCliente, updateAtendimento, registrarCheckin, listByClienteAndPeriod },
  casosNotificados: { list, create, updateStatus, countProximoAoItem, listProximosAoPonto, cruzamentosDoItem },
  unidadesSaude: { list, create, update },
  yoloFeedback: { upsert, getByItem },
  analiseIa: { getByLevantamento, triggerTriagem },
  sla: { listByCliente, listForPanel, updateStatus, pendingCount, verificarVencidos, escalar, reabrir },
  slaFeriados: { listByCliente, create, remove, seedNacionais },
  slaConfigRegiao: { listByCliente, upsert, remove },
  planoAcaoCatalogo: { listByCliente, listAllByCliente, create, update, remove },
  imoveis: { list, create, update, listProblematicos, marcarPrioridadeDrone, atualizarPerfil, countPrioridadeDroneByCliente },
  vistorias: { listByAgente, listByImovel, create, updateStatus, addDeposito, addSintomas, addRiscos, getResumoAgente, registrarSemAcesso, addCalha, listCalhas },
  pluvio: { riscoByCliente, latestRunByCliente },
  quotas: { byCliente, usoMensal, usoMensalAll, verificar, update },
  pushSubscriptions: { upsert, listByCliente, removeByEndpoint },
  drones: { list, create, update, remove },
  voos: { listByCliente, create, update, remove },
  usuarios: { listByCliente, listPapeis, update, updatePapel, remove },
  integracoes: { getByCliente, upsert, testarConexao },
  notificacoesESUS: { listByCliente, listByItem, enviar, descartar },
  cnesSync: { sincronizarManual, listarControle, listarLog, emAndamento },
  admin: { comparativoMunicipios },
  // ... e mais
}
```

### Padrão de implementação

```typescript
nomeFuncionalidade: {
  list: async (clienteId: string): Promise<TipoRetorno[]> => {
    const { data, error } = await supabase
      .from('nome_tabela')
      .select('*')
      .eq('cliente_id', clienteId)  // OBRIGATÓRIO — multitenancy
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },
}
```

### Problema crítico: tamanho do arquivo

Com **2.831 linhas**, o arquivo é o maior do projeto e cresce a cada sprint. Isso gera:

- Conflitos de merge em equipe
- Dificuldade de encontrar métodos específicos
- Risco de duplicar implementações sem perceber
- Tempo de parse do TypeScript aumentando

**Recomendação:** Dividir em arquivos por domínio (`api/sla.ts`, `api/levantamentos.ts`, etc.) com re-exportação em `api/index.ts`.

---

## Edge Functions

As Edge Functions rodam em Deno (runtime JavaScript/TypeScript) no Supabase. São ativadas via HTTP ou por agendamento (cron).

### 1. `cloudinary-upload-image`

**Trigger:** HTTP POST do frontend
**Responsabilidade:** Recebe arquivo de imagem, autentica com Cloudinary usando credenciais do servidor, faz upload e retorna a URL segura.

**Por que Edge Function e não direto do frontend?** Para nunca expor as credenciais Cloudinary no browser. Esta é a implementação correta de segurança.

---

### 2. `cloudinary-delete-image`

**Trigger:** HTTP POST do frontend
**Responsabilidade:** Deleta um asset do Cloudinary por `public_id`.

---

### 3. `cnes-sync`

**Trigger:** Cron 03:00 UTC + HTTP manual (por `cliente_id`)
**Responsabilidade:** Sincroniza unidades de saúde do CNES/DATASUS para cada cliente.

**Lógica:**
1. Modo agendado: percorre todos os clientes com `uf` + `ibge_municipio` cadastrados
2. Modo manual: sincroniza apenas o cliente informado
3. Busca unidades na API do CNES
4. Insere/atualiza `unidades_saude` com campos CNES
5. Inativa (soft delete) unidades ausentes que vieram do CNES
6. Registra em `unidades_saude_sync_controle` e `unidades_saude_sync_log`
7. Retry 3x com backoff exponencial em caso de falha

**Regra crítica:** Unidades com `origem='manual'` nunca são inativadas pela sync.

---

### 4. `geocode-regioes`

**Trigger:** HTTP
**Responsabilidade:** Geocodifica o endereço de uma região, retornando latitude e longitude.

---

### 5. `identify-larva`

**Trigger:** HTTP
**Responsabilidade:** Análise experimental de imagem para identificação de larvas do mosquito.

**Status:** Possivelmente ainda em desenvolvimento/POC.

---

### 6. `pluvio-risco-daily`

**Trigger:** Cron diário
**Responsabilidade:** Executa análise pluviométrica por região/bairro para todos os clientes. Cria registros em `pluvio_operacional_run` e `pluvio_operacional_item`.

---

### 7. `relatorio-semanal`

**Trigger:** Cron segunda-feira 08:00 UTC
**Responsabilidade:** Gera relatório HTML semanal por cliente e envia por email via Resend API.

**Dados incluídos:** Itens abertos/resolvidos, violações de SLA, focos por risco, operações da semana.

---

### 8. `resumo-diario`

**Trigger:** Cron diário
**Responsabilidade:** Gera resumo diário de operações por cliente.

---

### 9. `sla-marcar-vencidos`

**Trigger:** Cron a cada 15 minutos
**Responsabilidade:** Chama `marcar_slas_vencidos(cliente_id)` para todos os clientes. Marca `status='vencido'` e `violado=true` nos SLAs onde `prazo_final < NOW()`.

**Implicação:** Há uma janela de até 15 minutos onde SLAs vencidos ainda aparecem como `pendente` no banco. O frontend compensa isso calculando o status visual em tempo real via `getSlaVisualStatus()`.

---

### 10. `sla-push-critico`

**Trigger:** HTTP (chamado pelo `useSlaAlerts` hook)
**Responsabilidade:** Envia Web Push para operadores sobre SLAs com ≤ 1 hora restante.

---

### 11. `triagem-ia-pos-voo`

**Trigger:** HTTP
**Responsabilidade:**
1. Recebe `levantamento_id`
2. Agrupa itens por grade geográfica (0.001°)
3. Filtra possíveis falsos positivos (score baixo em cluster isolado)
4. Chama Claude Haiku para gerar sumário executivo em linguagem natural
5. Persiste resultado em `levantamento_analise_ia`

---

### 12. `upload-evidencia`

**Trigger:** HTTP
**Responsabilidade:** Upload específico para evidências de campo (fotos tiradas pelo operador).

---

## Triggers no banco de dados

Os triggers são a parte mais crítica do backend — executam lógica de negócio automaticamente ao inserir/atualizar registros.

### Triggers em `levantamento_itens`

| Trigger | Quando | O que faz |
|---------|--------|-----------|
| `trg_levantamento_item_criar_sla_auto` | AFTER INSERT | Cria `sla_operacional` com prazo calculado via config do cliente/região |
| `trg_levantamento_item_recorrencia` | AFTER INSERT | Detecta recorrência em 30d/50m; eleva prioridade para Urgente se recorrente |
| `trg_levantamento_item_status_historico` | AFTER UPDATE (status) | Grava mudança de status em tabela de auditoria |

**Ordem de execução:** Triggers em PostgreSQL são executados em ordem alfabética. O SLA (`_criar_sla`) executa antes da recorrência (`_recorrencia`) — correto, pois a recorrência pode atualizar o SLA recém-criado.

### Triggers em `vistorias`

| Trigger | Quando | O que faz |
|---------|--------|-----------|
| `trg_atualizar_perfil_imovel` | AFTER INSERT | Conta tentativas sem acesso; ao atingir 3, seta `prioridade_drone=true` no imóvel |
| `trg_sintomas_para_caso` | AFTER INSERT em `vistoria_sintomas` | Se `moradores_sintomas_qtd > 0`, cria `caso_notificado` automaticamente |

### Triggers em `casos_notificados`

| Trigger | Quando | O que faz |
|---------|--------|-----------|
| `trg_cruzar_caso_focos` | AFTER INSERT | Busca `levantamento_itens` em 300m (haversine), insere `caso_foco_cruzamento`, eleva prioridade para Crítico |

### Triggers em `operacoes`

| Trigger | Quando | O que faz |
|---------|--------|-----------|
| `trg_operacoes_on_status_concluido` | AFTER UPDATE (status=concluido) | Fecha `sla_operacional` correspondente |

### Triggers em `sla_config`

| Trigger | Quando | O que faz |
|---------|--------|-----------|
| Trigger de auditoria | AFTER UPDATE | Grava alteração em `sla_config_audit` |

---

## RPCs (Remote Procedure Calls)

Funções PL/pgSQL executadas via `supabase.rpc(...)`.

| RPC | Descrição |
|-----|-----------|
| `criar_levantamento_item_manual` | Cria item manual com validações (planejamento ativo, limite diário) |
| `get_meu_papel` | Retorna papel do usuário autenticado no cliente ativo |
| `gerar_slas_para_run` | Gera SLAs manualmente para um run pluviométrico |
| `sla_horas_from_config` | Calcula horas do SLA baseado na config do cliente/região |
| `sla_aplicar_fatores` | Aplica redutores climáticos ao prazo base |
| `sla_calcular_prazo_final` | Calcula prazo final considerando feriados e horário comercial |
| `marcar_slas_vencidos` | Marca SLAs expirados como vencido |
| `escalar_sla_operacional` | Escala prioridade de um SLA, preservando original |
| `escalar_prioridade` | Calcula próxima prioridade na escala |
| `listar_casos_no_raio` | Retorna casos notificados em raio ao redor de um ponto |
| `contar_casos_proximos_ao_item` | Conta casos próximos a um levantamento_item |
| `resumo_agente_ciclo` | Estatísticas de vistorias do agente no ciclo atual |
| `usuario_pode_acessar_cliente` | Valida se usuário tem acesso ao cliente |

---

## Pipeline Python (sistema externo)

O pipeline de drone não faz parte do código deste repositório — é um sistema Python separado.

**Interface com o Sentinella Web:**
1. Lê configurações em `sentinela_yolo_class_config` e `sentinela_drone_risk_config` via Supabase
2. Após processar voo, insere dados via RPC `criar_levantamento_item_manual`
3. Faz upload de imagens via Edge Function `cloudinary-upload-image`

**Risco:** Se o pipeline falhar silenciosamente (sem retry, sem log visível no sistema web), o gestor não sabe que o voo não foi processado. Não há mecanismo de status de voo visível na aplicação web.

---

## Pontos fortes do backend

1. Triggers garantem invariantes de negócio no nível mais baixo possível
2. RPCs encapsulam lógica complexa com validações de segurança
3. Credenciais sensíveis somente em Edge Functions
4. RLS como segunda linha de defesa além dos filtros da api.ts
5. Auditoria automática de SLA e status de itens via triggers

---

## Problemas do backend

### P1 — Lógica espalhada em camadas diferentes

A mesma regra de negócio pode estar em: trigger SQL, RPC PL/pgSQL, Edge Function TypeScript e frontend TypeScript. Sem uma lista clara de "quem é responsável por qual regra".

### P2 — Edge Functions sem retry configurado explicitamente

Além do `cnes-sync`, as outras Edge Functions não têm mecanismo visível de retry em caso de falha transitória (ex: timeout de rede).

### P3 — Sem mecanismo de dead letter queue

Operações offline da fila IndexedDB tentam executar ao reconectar, mas sem limite de tentativas ou notificação de falha persistente.

### P4 — cron sem monitoramento de execução

Não há painel visível de "última execução de cada cron" acessível ao administrador da plataforma.

### P5 — Haversine sem PostGIS

Cruzamento caso↔foco usa fórmula haversine em PL/pgSQL puro. Com muitos itens, isso pode ser lento. PostGIS com índice GIST seria a solução correta.

---

## Dúvidas em aberto

- O pipeline Python tem logs de execução visíveis no sistema web?
- Existe monitoramento de falhas nas Edge Functions (alertas por email ou Slack)?
- O cron `sla-marcar-vencidos` a cada 15 minutos é suficiente para o SLA mínimo de 2 horas?
- Quem é responsável por executar `seedDefaultSlaConfig` ao criar um novo cliente?
