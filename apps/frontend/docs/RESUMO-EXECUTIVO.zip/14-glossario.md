# 14 — Glossário do Sentinella Web

## Objetivo deste documento

Definir de forma clara e precisa todos os termos do domínio do sistema, termos técnicos relevantes e siglas utilizadas. Serve como referência para novos membros da equipe, stakeholders e parceiros.

---

## Termos do domínio de negócio

---

### Agente de Controle de Endemias
Profissional de saúde pública que visita imóveis domiciliar por domiciliar para inspecionar depósitos de água, aplicar larvicida e registrar riscos. No sistema, acessa o portal do Agente (`/agente/*`).

---

### Atendimento
O processo pelo qual um operador assume um item de levantamento, vai ao campo, trata o problema e o marca como resolvido. Gera histórico de auditoria.

---

### Bairro
Subdivisão geográfica de uma região, dentro do território de um cliente (prefeitura). Usado para organizar planejamentos e filtrar dados.

---

### Canal Cidadão
Funcionalidade que permite ao cidadão comum reportar suspeitas de foco de dengue via QR code, sem necessidade de login. Acessível em `/denuncia/:slug/:bairroId`.

---

### Caso Notificado
Registro de caso de dengue, chikungunya, zika ou suspeito, informado por uma unidade de saúde (UBS, UPA, hospital). Não contém dados pessoais identificáveis (LGPD). Pode ser cruzado automaticamente com focos próximos.

---

### Ciclo Epidemiológico
Período de trabalho dos agentes de controle de endemias. O ano é dividido em 6 ciclos bimestrais (ciclo 1=jan/fev, ciclo 2=mar/abr, ..., ciclo 6=nov/dez). Campo `ciclo` na tabela `vistorias`.

---

### Classificação de Risco
Atribuição de um nível de gravidade a um item de levantamento ou área. Valores: `alto`, `médio`, `baixo`. No contexto pluviométrico, inclui também `Muito Alto`.

---

### Cliente
Uma prefeitura municipal que contratou o Sentinella. Raiz de isolamento de dados no sistema (multitenancy). Todos os dados estão vinculados a um `cliente_id`.

---

### CNES
Cadastro Nacional de Estabelecimentos de Saúde. Sistema federal que lista todas as unidades de saúde do Brasil. O Sentinella sincroniza dados do CNES para manter o cadastro de unidades de saúde atualizado.

---

### Cruzamento Caso↔Foco
Processo automático (trigger no banco) que vincula casos notificados com focos de levantamento próximos (raio de 300m). Eleva a prioridade do foco para Crítico quando há casos próximos.

---

### Depósito PNCD
Tipo de depósito de água classificado pelo Programa Nacional de Controle da Dengue. Tipos: A1 (caixa d'água elevada), A2 (outros armazenamentos), B (pequenos recipientes), C (fixos grandes), D1 (pneus), D2 (lixo), E (naturais).

---

### Drone
Veículo aéreo não tripulado (VANT) usado para sobrevoo de regiões e captura de imagens para identificação de focos. O processamento das imagens é feito por pipeline Python externo.

---

### e-SUS Notifica
Sistema federal de notificação de doenças. O Sentinella possui integração para enviar casos confirmados diretamente, evitando duplicação de trabalho para o notificador.

---

### Escalamento
Ação administrativa de elevar a prioridade de um SLA vencido ou em risco de vencer, gerando novo prazo recalculado. Preserva a prioridade original para auditoria.

---

### Evidência
Registro fotográfico, dado GPS ou observação que comprova a identificação ou resolução de um foco. Armazenada no Cloudinary com vínculo rastreável no banco.

---

### ExifTool
Software open-source para leitura e escrita de metadados em arquivos (inclusive imagens). Usado no pipeline Python para extrair coordenadas GPS de imagens capturadas pelo drone.

---

### Falso Positivo
Item detectado pelo YOLO que não corresponde a um foco real. O operador pode marcar como falso positivo via botão "Não confirmado" no painel de detalhes. Os feedbacks são usados para re-treino do modelo.

---

### Foco de Dengue
Qualquer local com água parada ou condições favoráveis à reprodução do mosquito Aedes aegypti. Pode ser identificado por drone, vistoria manual ou denúncia de cidadão.

---

### GPS Checkin
Registro automático de localização GPS do agente/operador no momento do checkin em um imóvel ou item. Usado para auditoria de campo.

---

### Haversine
Fórmula matemática para calcular a distância entre dois pontos geográficos (latitude/longitude) na superfície da Terra. Usada no Sentinella para calcular raios de proximidade (300m para cruzamento, 500m para sugestão de planejamento).

---

### Heatmap
Mapa de calor que exibe a densidade de focos por área geográfica. O Sentinella tem heatmap estático e heatmap temporal animado (semana a semana).

---

### Imóvel
Edificação ou terreno cadastrado no sistema, visitável pelos agentes. Possui histórico de vistorias e perfil de acesso.

---

### Item de Levantamento (Levantamento Item)
Registro individual de um foco, evidência ou risco encontrado em um levantamento. Unidade básica de trabalho do operador. Tem ciclo de vida: `pendente → em_atendimento → resolvido`.

---

### Larvicida
Produto químico aplicado em depósitos de água para eliminar larvas do mosquito. Registrado nas vistorias de campo (tipo, quantidade em gramas).

---

### Levantamento
Agrupador de itens de um dia de operação. Ligado a um planejamento. Regra: apenas um levantamento por planejamento por dia. Tipo: DRONE ou MANUAL.

---

### LGPD
Lei Geral de Proteção de Dados Pessoais (Lei 13.709/2018). O Sentinella respeita a LGPD não armazenando dados pessoais identificáveis de pacientes em `casos_notificados`.

---

### LIRAa
Levantamento de Índice Rápido para Aedes aegypti. Metodologia do Ministério da Saúde para estimar a infestação por bairro/quarteirão. Módulo específico no Sentinella.

---

### Multitenancy
Modelo de software onde múltiplos clientes (prefeituras) compartilham a mesma infraestrutura, mas com isolamento completo de dados. No Sentinella, implementado via `cliente_id` em todas as tabelas + RLS no PostgreSQL.

---

### Notificador
Profissional de UBS/hospital que registra casos de dengue no sistema. Acessa o portal do Notificador (`/notificador/*`).

---

### Operador
Usuário responsável por atender focos de levantamento em campo. Acessa o portal do Operador (`/operador/*`) e vê apenas seus itens e SLAs atribuídos.

---

### Operação
Registro de atendimento de campo ligado a um item (pluvio ou levantamento). Status: `pendente → em_andamento → concluido`. Ao concluir, fecha automaticamente o SLA correspondente.

---

### Persistência Pluviométrica
Quantidade de dias consecutivos com chuva relevante. Um dos fatores de redução do prazo de SLA. Se persistência > 3 dias, aplica redutor de -20% no prazo.

---

### Pipeline de Drone
Módulo externo em Python que realiza: captura de imagens pelo drone → extração de EXIF (coordenadas GPS) → análise YOLO → upload Cloudinary → inserção no banco via RPC.

---

### Planejamento
Define ONDE e COMO será feita a operação: qual região/bairro, qual tipo (drone ou manual), qual data. Um planejamento pode gerar múltiplos levantamentos ao longo do tempo.

---

### Plano de Ação
Conjunto de ações corretivas tomadas após a identificação e validação de um problema. Pode ser selecionado do catálogo padronizado ou descrito livremente.

---

### Pluvio / Pluviometria
Medição de chuva. O módulo pluviométrico do Sentinella analisa dados climáticos por região para calcular risco de proliferação do Aedes aegypti e gerar SLAs preventivos.

---

### PNCD
Programa Nacional de Controle da Dengue. Define os tipos de depósito de água (A1-E) e os procedimentos de vistoria usados pelos agentes de endemias.

---

### Prioridade
Nível de urgência de um item ou SLA. Valores: `Crítico`, `Urgente`, `Alta`, `Moderada`, `Baixa`, `Monitoramento`. Afeta o prazo de SLA.

---

### PWA
Progressive Web App. Tecnologia que permite ao Sentinella ser instalado como aplicativo no celular e funcionar offline. Implementado com Workbox (Service Worker).

---

### Quarteirão
Divisão urbana usada nos levantamentos LIRAa. O sistema tem módulo de distribuição por quarteirão.

---

### Região
Estrutura geográfica cadastrada pelo cliente para organizar planejamentos. Uma região pertence a um cliente e pode ter configuração de SLA diferenciada.

---

### RLS (Row Level Security)
Funcionalidade do PostgreSQL que restringe quais linhas cada usuário pode ver/modificar, com base em políticas definidas. No Sentinella, garante que cada usuário veja apenas dados do seu cliente.

---

### RPC (Remote Procedure Call)
Função PL/pgSQL no Supabase chamada via `supabase.rpc(...)` do frontend ou de Edge Functions. Usada para operações complexas com validações de segurança.

---

### Score YOLO
Pontuação de confiança da detecção feita pelo modelo YOLO. Escala 0-1 (ou 0-100 no pipeline Python — normalizar antes de usar). Faixas: ≥0.85 muito alta, ≥0.65 alta, ≥0.45 média, <0.45 baixa.

---

### SLA (Service Level Agreement)
Prazo máximo para atendimento de um foco. No Sentinella, calculado automaticamente com base na prioridade, risco climático, feriados e configuração do cliente.

---

### Slug
Identificador amigável e legível por URL de um cliente. Usado no canal cidadão para identificar a prefeitura sem expor o `cliente_id` interno.

---

### Supervisor
Papel administrativo de um cliente (prefeitura). Equivale ao admin dentro do escopo do cliente — gerencia usuários, configurações, planejamentos e SLA.

---

### Triagem IA Pós-Voo
Análise automática dos itens de um levantamento de drone usando clustering geográfico + Claude Haiku para gerar um sumário executivo em linguagem natural. Ajuda o gestor a priorizar focos rapidamente após um voo.

---

### Unidade de Saúde
UBS (Unidade Básica de Saúde), UPA (Unidade de Pronto Atendimento) ou hospital cadastrado no sistema. Local onde casos de dengue são notificados. Dados sincronizados com CNES.

---

### Vistoria
Visita de um agente a um imóvel. Registra: acesso (ou não), moradores, sintomas, depósitos inspecionados, larvicida aplicado, riscos identificados. Pode ser salva offline.

---

### YOLO
"You Only Look Once" — modelo de visão computacional para detecção de objetos em imagens. No Sentinella, usado para identificar possíveis focos de dengue nas imagens capturadas pelo drone.

---

## Termos técnicos

| Termo | Definição |
|-------|-----------|
| **Edge Function** | Função serverless em Deno rodando no Supabase |
| **Haversine** | Fórmula de distância geográfica sem PostGIS |
| **IndexedDB** | Banco de dados no browser, usado para fila offline |
| **JWT** | JSON Web Token — formato do token de autenticação |
| **PostGIS** | Extensão PostgreSQL para dados geoespaciais com índices GIST |
| **React Query** | Biblioteca para cache e sincronização de estado do servidor |
| **Supabase** | Plataforma Backend-as-a-Service sobre PostgreSQL |
| **Trigger** | Função PL/pgSQL executada automaticamente no banco |
| **Web Push** | Notificações push via browser, mesmo sem o app aberto |
| **Workbox** | Biblioteca Google para criação de Service Workers |

---

## Siglas

| Sigla | Significado |
|-------|------------|
| CNES | Cadastro Nacional de Estabelecimentos de Saúde |
| LGPD | Lei Geral de Proteção de Dados Pessoais |
| LIRAa | Levantamento de Índice Rápido para Aedes aegypti |
| PNCD | Programa Nacional de Controle da Dengue |
| PWA | Progressive Web App |
| RBAC | Role-Based Access Control |
| RLS | Row Level Security |
| RPC | Remote Procedure Call |
| SaaS | Software as a Service |
| SINAN | Sistema de Informação de Agravos de Notificação |
| SLA | Service Level Agreement |
| UBS | Unidade Básica de Saúde |
| UPA | Unidade de Pronto Atendimento |
| YOLO | You Only Look Once (modelo de visão computacional) |
