# 02 — Arquitetura Geral

## Objetivo deste documento

Descrever a arquitetura técnica do Sentinella Web: camadas, decisões de design, fluxo de dados, integração entre componentes e o que está bem ou mal arquitetado.

---

## Visão geral em camadas

```
┌─────────────────────────────────────────────────────────────┐
│                     CAMADA DE APRESENTAÇÃO                  │
│  React 18 + TypeScript + Tailwind + Radix UI + Leaflet      │
│  44 páginas | 60+ componentes | PWA (Workbox)               │
└────────────────────────┬────────────────────────────────────┘
                         │ TanStack React Query (cache + sync)
┌────────────────────────▼────────────────────────────────────┐
│                    CAMADA DE SERVIÇO                        │
│         src/services/api.ts  (2.831 linhas)                 │
│  Único ponto de acesso ao Supabase — 20+ namespaces         │
└────────────────────────┬────────────────────────────────────┘
                         │ supabase-js client
┌────────────────────────▼────────────────────────────────────┐
│                    CAMADA DE BACKEND                        │
│     Supabase (PostgreSQL + Auth + RLS + Edge Functions)     │
│  35+ migrations | 12 Edge Functions | 15+ triggers | RPCs   │
└────────────────────────┬────────────────────────────────────┘
                         │
         ┌───────────────┴───────────────┐
         ▼                               ▼
  ┌─────────────┐               ┌──────────────────┐
  │  Cloudinary │               │  Serviços externos│
  │  (imagens)  │               │  Resend, e-SUS,  │
  └─────────────┘               │  CNES, Web Push  │
                                └──────────────────┘

         ┌───────────────────────────────┐
         │   PIPELINE EXTERNO (Python)   │
         │ ExifTool → YOLO → Supabase    │
         └───────────────────────────────┘
```

---

## Decisões arquiteturais

### 1. Supabase como backend completo

**Decisão:** Usar Supabase como única camada de backend — banco PostgreSQL, autenticação, políticas de acesso (RLS), funções serverless (Edge Functions) e tempo real.

**Por que:** Reduz drasticamente o tempo de desenvolvimento. Evita manter um servidor Node/Express separado.

**Trade-offs:**
- ✅ Banco + Auth + API em um serviço
- ✅ RLS garante segurança no nível do banco
- ❌ Vendor lock-in significativo
- ❌ Edge Functions têm limitações (sem estado, sem bibliotecas C nativas, Deno runtime)
- ❌ Lógica de negócio distribuída entre frontend, Edge Functions e triggers PL/pgSQL

---

### 2. api.ts como camada de serviço única

**Decisão:** Todo acesso ao Supabase passa por `src/services/api.ts`. Componentes de página nunca acessam `supabase` diretamente.

**Por que:** Centralização facilita mocking, testes, mudança de provider e auditoria.

**Problema atual:** O arquivo tem 2.831 linhas e cresce continuamente sem subdivisão por domínio. Isso é um **risco de manutenção** — dificulta onboarding e aumenta chance de conflitos em equipe.

---

### 3. React Query para estado do servidor

**Decisão:** TanStack React Query v5 para todo estado derivado do servidor. Cache granular com constantes `STALE.*` em `queryConfig.ts`.

**Por que:** Evita prop drilling, gerencia loading/error/refetch, suporta polling e invalidação cirúrgica.

**Resultado:** 45+ hooks de query com estratégias diferentes (LIVE=0ms para SLA, STATIC=30min para configurações).

---

### 4. Multitenancy via cliente_id + RLS

**Decisão:** Isolamento de dados por `cliente_id` em todas as tabelas, com Row Level Security (RLS) no PostgreSQL garantindo que cada usuário só acesse dados do seu cliente.

**Por que:** Mais seguro que filtrar apenas no frontend — o banco rejeita queries inválidas.

**Como funciona:**
```sql
-- Exemplo de política RLS
CREATE POLICY "isolamento_por_cliente" ON levantamento_itens
  USING (cliente_id IN (
    SELECT cliente_id FROM usuarios WHERE auth_id = auth.uid()
  ));
```

**Problema identificado:** Algumas tabelas adicionadas em migrations mais recentes não têm RLS verificado — ver `06-rls-e-seguranca.md`.

---

### 5. Regras de negócio distribuídas em 3 camadas

Esta é a maior **fragilidade arquitetural** do sistema. As regras estão em:

| Camada | Exemplos de regras |
|--------|-------------------|
| **Frontend** | Normalização de score YOLO, cálculo visual de SLA, ciclos epidemiológicos, validação de depósitos |
| **api.ts** | Filtro por cliente_id, construção de queries |
| **Banco (triggers)** | SLA automático, recorrência, cruzamento caso↔foco, histórico de status |
| **Edge Functions** | Triagem IA, relatório semanal, sync CNES, push de SLA crítico |
| **sla.ts** | Cálculo de prazos, redutores, status visual |

**Risco:** Uma regra duplicada em dois lugares pode divergir. Uma regra só no frontend pode ser contornada por insert direto no banco.

---

### 6. Pipeline de Drone como sistema externo

**Decisão:** O processamento de voo (ExifTool + YOLO) roda em Python separado, não no Supabase.

**Por que:** YOLO requer GPU/hardware específico; não cabe em Edge Function.

**Interface:** O pipeline Python insere dados via RPC `criar_levantamento_item_manual` no Supabase.

**Fragilidade:** Falha no pipeline Python não é visível na aplicação web — sem mecanismo de retry ou alertas para o gestor.

---

## Fluxo de dados típico

### Criação de item (manual pelo operador)

```
1. Operador preenche formulário → VistoriaEtapa3 component
2. handleFinalize() → api.vistorias.create(payload)
3. api.ts → supabase.rpc('criar_levantamento_item_manual', {...})
4. RPC no banco:
   a. Verifica planejamento ativo
   b. Verifica limite diário
   c. Cria/reutiliza levantamento do dia
   d. Insere levantamento_item
   e. Trigger: cria sla_operacional
   f. Trigger: detecta recorrência
5. React Query invalida queryKey ['levantamento-itens', clienteId]
6. UI re-renderiza com novo item
```

### Consulta de mapa (operador)

```
1. OperadorMapa monta → useMapData(clienteId) hook
2. React Query: cache STALE.MAP (10min)
3. api.itens.listMapByCliente(clienteId)
4. Supabase query com RLS → retorna só items do cliente
5. Items renderizados em Leaflet com MarkerCluster
6. Clique em marcador → ItemDetailPanel com dados do item
```

---

## Arquitetura de segurança

```
Browser → Supabase Auth (JWT) → RLS policies (banco)
                                    ↓
                              Toda query filtrada
                              por cliente_id via
                              auth.uid() → usuarios → cliente_id
```

**Credenciais sensíveis:**
- Cloudinary API Key: apenas em Edge Function (nunca no frontend)
- Resend API Key: apenas em Edge Function
- CNES API: apenas em Edge Function

---

## PWA e modo offline

```
Service Worker (Workbox) → cache de assets estáticos
offlineQueue.ts (IndexedDB) → operações pendentes
useOfflineQueue.ts → drena fila ao reconectar
OfflineBanner → feedback visual para o operador
```

**Operações suportadas offline:**
- `checkin` — checkin de item
- `update_atendimento` — atualização de status
- `save_vistoria` — vistoria completa (create + depositos + sintomas + riscos)

---

## Edge Functions e seus papéis

| Função | Trigger | Responsabilidade |
|--------|---------|-----------------|
| `cloudinary-upload-image` | HTTP (frontend) | Upload seguro de imagens |
| `cloudinary-delete-image` | HTTP (frontend) | Deleção de imagens |
| `cnes-sync` | Cron 03h UTC + HTTP | Sync unidades de saúde do CNES |
| `geocode-regioes` | HTTP | Geocodificação de regiões |
| `identify-larva` | HTTP | IA para identificação de larvas (experimental) |
| `pluvio-risco-daily` | Cron (diário) | Análise pluviométrica por região |
| `relatorio-semanal` | Cron seg 8h UTC | Relatório HTML por email (Resend) |
| `resumo-diario` | Cron (diário) | Resumo diário por cliente |
| `sla-marcar-vencidos` | Cron a cada 15min | Marca SLAs expirados |
| `sla-push-critico` | HTTP | Web Push para SLAs ≤ 1h |
| `triagem-ia-pos-voo` | HTTP | Cluster + Claude haiku + sumário |
| `upload-evidencia` | HTTP | Upload de evidências de campo |

---

## Pontos fortes da arquitetura

1. **Separação clara entre apresentação e serviço** — api.ts como barreira consistente
2. **Triggers de banco garantem invariantes** — SLA, recorrência e cruzamentos não dependem do frontend
3. **Cache granular e inteligente** — React Query com STALE diferenciado por tipo de dado
4. **Segurança em profundidade** — RLS + filtros na api.ts + sem credenciais no frontend
5. **Offline-first real** — IndexedDB, não apenas cache HTTP

---

## Problemas arquiteturais identificados

### P1 — api.ts monolítico (CRÍTICO)

`src/services/api.ts` tem 2.831 linhas e cresce. Não há divisão por domínio. Qualquer novo recurso entra neste arquivo.

**Impacto:** Conflitos de merge em equipe, dificuldade de onboarding, tempo de carregamento do módulo no editor.

**Sugestão:** Dividir em `api/levantamentos.ts`, `api/sla.ts`, `api/vistoria.ts`, etc., exportando um objeto `api` unificado via `api/index.ts`.

---

### P2 — Regras de negócio distribuídas (ALTO)

Mesma regra em frontend e banco sem garantia de sincronismo. Exemplo: validação de `qtd_com_focos <= qtd_inspecionados` — só no frontend, sem CHECK constraint no banco.

**Impacto:** Inserção direta no banco pode violar regras.

---

### P3 — Schema.sql desatualizado (MÉDIO)

O arquivo `schema.sql` não reflete fielmente o estado atual após 35+ migrations. Isso dificulta entender o estado real do banco.

---

### P4 — Sem testes automatizados visíveis (ALTO)

Playwright e Vitest estão nas dependências mas sem evidência de suíte de testes cobrindo fluxos críticos.

---

### P5 — Lógica de ciclos no frontend (BAIXO)

`Math.ceil((new Date().getMonth() + 1) / 2)` calculado no frontend sem persistir no banco. Retroativamente inconsistente.

---

## Dúvidas em aberto

- Existe um ambiente de staging separado do produção?
- O pipeline Python tem mecanismo de retry em caso de falha?
- Há monitoramento de erros (Sentry, Datadog) na aplicação?
- As Edge Functions têm logs de erro acessíveis ao time?
