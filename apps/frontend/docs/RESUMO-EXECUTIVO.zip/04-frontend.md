# 04 — Frontend

## Objetivo deste documento

Descrever a estrutura do frontend do Sentinella Web: organização de páginas, componentes, hooks, estado, roteamento e as principais fragilidades identificadas.

---

## Stack de frontend

| Tecnologia | Versão | Papel |
|-----------|--------|-------|
| React | 18.3.1 | Framework de UI |
| TypeScript | 5.8.3 | Tipagem estática |
| Vite + SWC | Latest | Build e transpilação |
| Tailwind CSS | 3.4.17 | Estilo utilitário |
| Radix UI | — | Componentes acessíveis (primitives) |
| shadcn/ui | — | Componentes compostos sobre Radix |
| TanStack React Query | 5.83.0 | Cache e sync de estado do servidor |
| React Router | 6.30.1 | Roteamento SPA |
| Leaflet + React-Leaflet | 1.9.4 | Mapas interativos |
| Recharts | 2.15.4 | Gráficos e analytics |
| Workbox (PWA) | — | Service Worker, cache offline |

---

## Estrutura de pastas

```
src/
├── pages/              # 44 páginas organizadas por perfil
│   ├── admin/          # 28 páginas de administração
│   ├── agente/         # 2 páginas do agente de campo
│   ├── gestor/         # 3 páginas do gestor
│   ├── notificador/    # 2 páginas do notificador
│   ├── operador/       # 5 páginas do operador
│   └── public/         # Dashboard, Login, Mapa, Install, NotFound
├── components/         # 60+ componentes reutilizáveis
│   ├── dashboard/      # 18 widgets de KPI e charts
│   ├── levantamentos/  # 12 componentes de levantamentos e itens
│   ├── foco/           # Cards, badges, timelines de focos
│   ├── vistoria/       # Etapas do formulário de vistoria
│   ├── layouts/        # AppLayout, PublicLayout
│   └── ...
├── hooks/              # Hooks customizados
│   ├── queries/        # 45+ hooks de React Query (dados)
│   └── useClienteAtivo.tsx  # Hook central de multitenancy
├── services/
│   └── api.ts          # ÚNICO ponto de acesso ao Supabase (2.831 linhas)
├── types/
│   ├── database.ts     # 50+ interfaces TypeScript (1.410 linhas)
│   └── sla.ts          # Tipos e lógica de SLA (143 linhas)
├── lib/                # Utilitários, seeds, PDF, geo, mídia
└── App.tsx             # Roteamento principal
```

---

## Roteamento (App.tsx)

### Páginas públicas (sem autenticação)

```
/                       → Dashboard (requer auth, redireciona)
/login                  → Tela de login
/denuncia/:slug/:bairroId → Canal Cidadão (completamente público)
/consulta-protocolo     → Consulta de protocolo de denúncia
/install                → Instruções de instalação do PWA
```

### Área autenticada — perfis e rotas

```
/dashboard              → Dashboard principal (todos os papéis)
/mapa                   → Mapa de inspeção
/levantamentos          → Lista de levantamentos
/levantamentos/:id      → Detalhe do levantamento

/admin/clientes         → CRUD de clientes (admin only)
/admin/usuarios         → Gestão de usuários
/admin/planejamentos    → Gestão de planejamentos
/admin/regioes          → Regiões e bairros
/admin/sla              → Gestão de SLA
/admin/sla-feriados     → Feriados do cliente
/admin/operacoes        → Operações de campo
/admin/historico-atendimento → Histórico por localização
/admin/pluvio-risco     → Risco pluviométrico
/admin/pluvio-operacional → Tabela pluviométrica
/admin/risk-policy      → Política de risco
/admin/voos             → Histórico de voos
/admin/imoveis          → Gestão de imóveis
/admin/imoveis-problematicos → Imóveis com acesso negado
/admin/casos            → Casos notificados
/admin/canal-cidadao    → QR + lista de denúncias
/admin/unidades-saude   → CRUD unidades + CNES sync
/admin/integracoes      → Configuração e-SUS Notifica
/admin/plano-acao-catalogo → Catálogo de planos
/admin/quotas           → Quotas do cliente
/admin/drones           → Gestão de drones
/admin/liraa            → Módulo LIRAa
/admin/quarteirao       → Distribuição por quarteirão
/admin/produtividade    → Produtividade dos agentes
/admin/municipios       → Comparativo entre municípios
/admin/score-surto      → Score de surto
/admin/yolo-qualidade   → Qualidade das detecções YOLO
/admin/supervisor-tempo-real → Supervisão em tempo real
/admin/heatmap-temporal → Heatmap animado
/admin/mapa-comparativo → Comparação antes/depois

/operador               → SLA Operacional do operador
/operador/mapa          → Mapa do operador
/operador/levantamentos → Meus itens
/operador/levantamentos/novo-item → Criar item manual
/operador/inicio        → Início de turno
/operador/imoveis       → Lista de imóveis
/operador/vistoria/:imovelId → Formulário de vistoria

/agente/hoje            → Agenda do agente
/agente/vistoria        → Vistoria do agente

/gestor/focos           → Focos do gestor
/gestor/foco/:id        → Detalhe do foco
/gestor/mapa            → Mapa do gestor

/notificador            → Home do notificador
/notificador/registrar  → Registrar caso
```

---

## Hooks de dados (React Query)

Os hooks ficam em `src/hooks/queries/` e seguem o padrão:

```typescript
export function useNomeFuncionalidade(clienteId: string | null | undefined) {
  return useQuery({
    queryKey: ['nome-funcionalidade', clienteId],
    queryFn: () => api.nomeFuncionalidade.list(clienteId!),
    enabled: !!clienteId,
    staleTime: STALE.MEDIUM,
  });
}
```

### Estratégia de cache por tipo de dado

| STALE | Valor | Usado para |
|-------|-------|-----------|
| `LIVE` | 0ms | SLA ativo, alertas críticos |
| `VERY_SHORT` | 30s | Painel SLA com polling |
| `SHORT` | 1min | Casos, operações em andamento |
| `RECENT` | 2min | Quotas, evidências |
| `MEDIUM` | 3min | Levantamentos, items de mapa |
| `MODERATE` | 5min | Pluvio, planejamentos |
| `MAP` / `LONG` | 10min | Dados cartográficos pesados |
| `EXTENDED` | 15min | Condições de voo |
| `STATIC` | 30min | Catálogos, configurações |
| `SESSION` | Infinity | Policies de risco, YOLO config |

---

## Multitenancy no frontend

O hook `useClienteAtivo` é o ponto central:

```typescript
import { useClienteAtivo } from '@/hooks/useClienteAtivo';
const { clienteId, clienteAtivo, clientes } = useClienteAtivo();
```

**Regra:** Nenhum componente de página deve derivar `clienteId` de outra forma. O hook encapsula:
- Carregamento do cliente ativo do contexto
- Permissão para admin trocar de cliente (simulação de outro cliente)
- Carregamento do papel do usuário via RPC `get_meu_papel`

---

## Componentes críticos

### ItemDetailPanel.tsx

O componente mais complexo do sistema. Exibe o painel de detalhes de um item de levantamento.

**Responsabilidades:**
- Score YOLO com normalização e barra de confiança
- Histórico de recorrência (endereço repetido em 30 dias)
- Timeline de auditoria SLA (criado → em_atendimento → resolvido)
- Banner de casos notificados próximos (300m)
- Botão de falso positivo (feedback para re-treino YOLO)
- Botão "Notificar ao e-SUS"
- Assistente de voz (comandos: marcar resolvido, próximo, anterior)

**Problema:** Este componente acumula muitas responsabilidades. Com o tempo, tende a ficar cada vez maior e difícil de manter.

---

### OperadorFormularioVistoria.tsx

Stepper de 5 etapas para vistoria de campo. Gerencia estado complexo:

- Estado de cada etapa (moradores, sintomas, depósitos, tratamento, riscos)
- Modo `semAcessoMode` — alterna para fluxo alternativo sem percorrer o stepper
- `handleFinalize` — persiste calhas, atualiza perfil do imóvel, enfileira offline se sem rede

**Problema:** Componente de página com lógica de orquestração complexa. Estado compartilhado entre etapas sem Context, passado via props. Difícil de testar.

---

### HeatmapLayer.tsx

Componente de camada de heatmap Leaflet. Deve ser reutilizado em todos os mapas.

**Problema:** Leaflet tem efeitos colaterais no DOM que exigem cuidado com React StrictMode e unmounting.

---

## Dashboard — Widgets

18 widgets no dashboard, cada um com seu próprio hook de dados:

| Widget | Dados |
|--------|-------|
| `StatsGrid` | KPIs gerais (itens, resolvidos, pendentes) |
| `SlaWidget` | Contagem de SLAs por status |
| `PainelSLAResumo` | Resumo detalhado de SLA |
| `PluvioRiskWidget` | Risco pluviométrico com alerta janela pós-chuva |
| `CasosNotificadosWidget` | Casos confirmados/suspeitos + focos cruzados |
| `AtendimentoStatusWidget` | Status do atendimento |
| `PriorityChart` | Distribuição por prioridade |
| `RiskDistributionChart` | Distribuição por risco |
| `SlaEvolutionChart` | Evolução de SLA ao longo do tempo |
| `StormAlertWidget` | Alerta de tempestade |
| `ResumoDiarioWidget` | Resumo das operações do dia |
| `ScoreSurtoWidget` | Score de surto por bairro |
| `OperacoesWidget` | Operações de campo em andamento |
| `OperacionalWidget` | Painel operacional geral |

**Problema:** Cada widget faz sua própria query. Em um dashboard com 14 widgets ativos, isso gera 14+ queries simultâneas ao montar a página. Sem agrupamento ou prefetch coordenado.

---

## PWA e modo offline

```
public/sw.js                → Service Worker (Workbox)
src/lib/offlineQueue.ts     → Fila IndexedDB
src/hooks/useOfflineStatus.ts → Detecção de conectividade
src/hooks/useOfflineQueue.ts  → Drenagem ao reconectar
src/components/OfflineBanner.tsx → Feedback visual
```

**Operações offline suportadas:**
- `checkin` — checkin de item de levantamento
- `update_atendimento` — atualização de status
- `save_vistoria` — vistoria completa (sequência: create → depositos → sintomas → riscos)

**Problema:** A operação `save_vistoria` é uma sequência de 4 chamadas que devem ser executadas em ordem. Se a rede cair no meio da drenagem, pode ficar em estado parcial sem mecanismo de compensação.

---

## Pontos fortes do frontend

1. **Separação clara** entre página, componente e hook de dados
2. **Multitenancy centralizado** no `useClienteAtivo` hook
3. **Cache inteligente** com STALE diferenciado por tipo
4. **Mobile-first real** — vistoria e operador otimizados para smartphone
5. **TypeScript rigoroso** — 1.410 linhas de tipos bem definidos
6. **Componentes Radix/shadcn** — acessibilidade e consistência visual

---

## Problemas do frontend

### P1 — api.ts monolítico (2.831 linhas)

Já descrito em `03-backend.md`. O frontend sente o impacto com imports lentos e dificuldade de encontrar métodos.

### P2 — Componentes de página com lógica de negócio

`OperadorFormularioVistoria.tsx`, `ItemDetailPanel.tsx` e `AdminCasosNotificados.tsx` são exemplos de componentes que mistura orquestração de negócio com renderização. Dificulta testes unitários.

### P3 — 14+ queries no dashboard sem coordenação

Cada widget faz sua query independentemente. Pode gerar:
- Múltiplas chamadas ao Supabase simultâneas
- Tela de loading fragmentada (cada widget carregando em momentos diferentes)

### P4 — Cálculo de ciclos apenas no frontend

`Math.ceil((new Date().getMonth() + 1) / 2)` define o ciclo epidemiológico atual. Não é persistido no banco. Se calculado em momentos diferentes (criação vs leitura), pode gerar inconsistências retroativas.

### P5 — Leaflet e React StrictMode

Leaflet não foi projetado para React StrictMode (double-mounting). Pode causar erros silenciosos de renderização de mapa.

### P6 — Sem testes de componentes visíveis

Playwright e Vitest estão nas dependências, mas sem evidência de cobertura de testes nos componentes críticos.

---

## Dúvidas em aberto

- Qual é a estratégia de code splitting? Há lazy loading por rota?
- Existe análise de bundle size (vite-bundle-visualizer)?
- Os componentes de mapa Leaflet são lazy-loaded separadamente?
- Qual é o comportamento em iOS Safari (limitações de Web Push e PWA)?
- Há testes de acessibilidade (a11y) para o formulário de vistoria?
