# 10 — Riscos e Falhas

## Objetivo deste documento

Identificar e analisar riscos de segurança, operacionais, de regressão, de dados e de escalabilidade no sistema Sentinella Web.

---

## Classificação de risco

| Severidade | Descrição |
|-----------|-----------|
| **CRÍTICO** | Pode causar perda de dados, vazamento de dados entre prefeituras, ou parada total do sistema |
| **ALTO** | Pode causar bug em produção, violação de regra de negócio ou degradação significativa |
| **MÉDIO** | Risco controlado, impacto moderado, contornável manualmente |
| **BAIXO** | Impacto pequeno, pode ser ignorado no curto prazo |

---

## RISCOS DE SEGURANÇA

### RS-01 — Credenciais do pipeline Python não documentadas (CRÍTICO)

**Situação:** O pipeline externo Python precisa acessar o Supabase para ler configs e inserir dados. Não está documentado qual chave é usada.

**Risco:** Se for `service_role` key:
- Bypassa completamente o RLS
- Pode ler dados de TODOS os clientes
- Pode escrever em qualquer tabela sem restrição

**Probabilidade:** Média — pipelines de ingestão frequentemente usam service_role por conveniência
**Impacto:** Crítico — viola o modelo de multitenancy

**Mitigação:** Auditar o código Python e substituir por usuário de serviço com papel restrito + RLS aplicado.

---

### RS-02 — Sem proteção de rota por papel no frontend (ALTO)

**Situação:** O controle de acesso por papel (`admin`, `operador`, etc.) é feito no frontend para esconder/mostrar menus, mas não há `ProtectedRoute` com verificação de papel antes de renderizar a página.

**Risco:** Um usuário com papel `operador` pode acessar `/admin/clientes` digitando a URL manualmente.

**Probabilidade:** Baixa — requer conhecimento da URL
**Impacto:** Alto — veria a tela de gestão de clientes (mesmo que as queries retornem apenas dados do seu cliente por RLS)

**Mitigação:** Adicionar componente `RoleGuard` que verifica o papel antes de renderizar qualquer rota admin.

---

### RS-03 — Sem rate limiting no canal cidadão (MÉDIO)

**Situação:** A rota `/denuncia/:slug/:bairroId` é pública e não tem rate limiting.

**Risco:** Bot pode enviar milhares de denúncias spam, poluindo a base de dados da prefeitura.

**Probabilidade:** Baixa — requer ataque direcionado
**Impacto:** Médio — dados poluídos, degradação do painel de denúncias

**Mitigação:** Rate limiting por IP na Edge Function ou no RPC (ex: máx 10 denúncias/hora por IP).

---

### RS-04 — Variáveis VITE_* expostas no bundle (MÉDIO)

**Situação:** Build Vite com prefix `VITE_` expõe a variável no bundle JavaScript do browser.

**Risco:** Se qualquer API key, URL secreta ou configuração sensível estiver em `VITE_*`, fica acessível via DevTools.

**Probabilidade:** Desconhecida — depende do que está em `.env.production`
**Impacto:** Variável — depende do que está exposto

**Mitigação:** Auditar arquivo `.env.production` e remover qualquer valor sensível de variáveis `VITE_*`.

---

## RISCOS DE DADOS

### RD-01 — Payload JSONB sobrescrito com múltiplos casos (ALTO)

**Situação:** O trigger de cruzamento caso↔foco faz:
```sql
SET payload = jsonb_set(payload::jsonb, '{caso_notificado_proximidade}', to_jsonb(NEW.id))
```

**Risco:** Se 3 casos estiverem próximos ao mesmo foco, apenas o último `caso_id` fica no payload. Os 2 primeiros são perdidos (não na tabela `caso_foco_cruzamento`, mas no payload do item).

**Probabilidade:** Alta — em áreas com surto, múltiplos casos próximos são esperados
**Impacto:** Médio — a tabela `caso_foco_cruzamento` tem todos os vínculos; apenas o payload está errado

**Mitigação urgente:**
```sql
SET payload = jsonb_set(
  COALESCE(payload, '{}')::jsonb,
  '{casos_notificados_proximos}',
  COALESCE(payload->'casos_notificados_proximos', '[]')::jsonb || to_jsonb(NEW.id)
)
```

---

### RD-02 — Vistoria salva parcialmente no modo offline (ALTO)

**Situação:** A operação `save_vistoria` offline é uma sequência de 4+ chamadas (create → depositos → sintomas → riscos). Se a rede voltar e falhar no meio da drenagem, a vistoria fica em estado parcial.

**Risco:** Vistoria com dados incompletos gravados — sem os sintomas ou sem os depósitos.

**Probabilidade:** Baixa — requer falha de rede muito específica durante a drenagem
**Impacto:** Alto — dados epidemiológicos incompletos

**Mitigação:** Implementar transação ou rollback na drenagem. Se qualquer step falhar, reverter os anteriores ou marcar para re-tentativa completa.

---

### RD-03 — Ciclo epidemiológico sem janela temporal (MÉDIO)

**Situação:** O trigger `trg_atualizar_perfil_imovel` conta tentativas sem acesso sem janela temporal. 3 tentativas ao longo de 1 ano têm o mesmo peso que 3 em 1 semana.

**Risco:** Imóveis marcados para drone por tentativas antigas, quando o problema pode ter sido resolvido.

**Probabilidade:** Média
**Impacto:** Baixo — apenas alocação incorreta de recursos de drone

---

### RD-04 — Imagens Cloudinary sem vínculo no banco (MÉDIO)

**Situação:** O upload é feito ANTES do INSERT no banco. Se o INSERT falhar após o upload bem-sucedido, a imagem fica órfã no Cloudinary.

**Risco:** Acúmulo de assets no Cloudinary sem referência correspondente (aumenta custo de storage).

**Probabilidade:** Baixa mas plausível
**Impacto:** Baixo (custo) + Médio (imagens de evidência perdidas)

**Mitigação:** Cleanup periódico no Cloudinary comparando com `image_url` nas tabelas do banco.

---

## RISCOS DE REGRESSÃO

### RR-01 — Sem testes automatizados cobrindo triggers (CRÍTICO)

**Situação:** Os triggers de SLA, recorrência e cruzamento de casos são a espinha dorsal do sistema. Não há testes automatizados visíveis para eles.

**Risco:** Uma migration futura pode quebrar um trigger silenciosamente. Regressão em produção.

**Probabilidade:** Alta — triggers são frágeis a mudanças de schema
**Impacto:** Crítico — SLA não criado automaticamente = operadores não alertados

**Mitigação:** Criar testes de integração no banco (pgTAP ou equivalente) cobrindo:
- Trigger de SLA automático ao inserir item
- Trigger de recorrência
- Trigger de cruzamento caso↔foco
- Trigger de atualização de perfil de imóvel

---

### RR-02 — Ordem de triggers por nome (MÉDIO)

**Situação:** PostgreSQL executa triggers no mesmo evento em **ordem alfabética por nome**. O sistema depende que `trg_levantamento_item_criar_sla_auto` execute antes de `trg_levantamento_item_recorrencia`.

**Risco:** Um novo trigger com nome alfabeticamente anterior (`trg_atualizar_...`) poderia quebrar a ordem esperada.

**Probabilidade:** Baixa — risco de engenharia
**Impacto:** Alto — recorrência poderia tentar atualizar um SLA que ainda não foi criado

**Mitigação:** Documentar a dependência de ordem e verificar ao criar novos triggers em `levantamento_itens`.

---

### RR-03 — Divergência entre cálculo de SLA no frontend e banco (ALTO)

**Situação:** `calcularSlaHoras()` em `sla.ts` e `sla_aplicar_fatores()` no banco são implementações separadas da mesma lógica.

**Risco:** Uma mudança em uma não é replicada na outra. O operador vê um prazo no frontend diferente do que está no banco.

**Probabilidade:** Média — cada sprint pode trazer mudanças nos coeficientes
**Impacto:** Alto — operador toma decisão baseada em SLA errado

---

## RISCOS OPERACIONAIS

### RO-01 — Pipeline Python sem status visível no sistema (ALTO)

**Situação:** O pipeline de drone processa imagens em background. Não há mecanismo para saber no sistema web se o processamento foi bem-sucedido, falhou ou está em andamento.

**Risco:** Gestor acha que voo não gerou itens quando na verdade o pipeline está processando ou falhou.

**Probabilidade:** Alta — é o fluxo mais crítico do produto
**Impacto:** Alto — decisões operacionais atrasadas

**Mitigação:** Criar campo `status_processamento` em `levantamentos` com valores `aguardando | processando | concluido | erro` atualizado pelo pipeline.

---

### RO-02 — Janela de 15 minutos nos SLAs vencidos (MÉDIO)

**Situação:** Entre execuções da Edge Function `sla-marcar-vencidos`, SLAs que venceram aparecem como `pendente` no banco.

**Risco:** Operador vê item como "em dia" no banco, mas o frontend mostra como "vencido" (calculado em tempo real).

**Probabilidade:** Certa — acontece a cada 15 minutos
**Impacto:** Baixo — frontend compensa; relatórios gerados nessa janela podem ter contagem incorreta

---

### RO-03 — CNES sync falha sem notificação ao admin (MÉDIO)

**Situação:** A Edge Function `cnes-sync` tem retry 3x com backoff, mas se todas as tentativas falharem, o admin não é notificado automaticamente.

**Risco:** Unidades de saúde desatualizadas por dias sem que o admin saiba.

**Probabilidade:** Baixa
**Impacto:** Médio — dados de unidades desatualizados, impacta registro de casos

---

### RO-04 — Web Push não funciona em iOS Safari (MÉDIO)

**Situação:** Web Push API tem suporte limitado em iOS Safari (apenas a partir do iOS 16.4 e apenas em PWA instalado).

**Risco:** Operadores com iPhone podem não receber alertas de SLA crítico.

**Probabilidade:** Alta — iPhones são comuns no Brasil
**Impacto:** Médio — alertas não chegam; operador depende de polling visual

**Mitigação:** Implementar fallback in-app (toast + badge visível) que já existe via `useSlaAlerts`.

---

## RISCOS DE ESCALABILIDADE

### RE-01 — Haversine sem PostGIS (MÉDIO)

**Situação:** Cruzamento caso↔foco usa haversine em PL/pgSQL puro.

**Risco:** Com 10.000+ itens por cliente, cada novo caso notificado executa O(n) comparações.

**Probabilidade:** Alta em municípios grandes após meses de uso
**Impacto:** Médio — trigger lento no INSERT de casos notificados

**Mitigação:** Habilitar PostGIS e usar `ST_DWithin` com índice GIST.

---

### RE-02 — api.ts parse lento em IDEs (BAIXO)

**Situação:** 2.831 linhas em um arquivo TypeScript degrada a experiência no VS Code.

**Probabilidade:** Certa
**Impacto:** Baixo para produção, Alto para produtividade de desenvolvimento

---

### RE-03 — Dashboard com N queries simultâneas (MÉDIO)

**Situação:** 14+ widgets disparando queries simultâneas ao montar o dashboard.

**Risco:** Com múltiplos usuários simultâneos, pode sobrecarregar o connection pool do Supabase.

**Probabilidade:** Média em cenário de múltiplas prefeituras
**Impacto:** Médio — degradação de performance para todos

---

## Matriz de risco consolidada

| ID | Risco | Severidade | Probabilidade | Prioridade |
|----|-------|-----------|--------------|-----------|
| RS-01 | Credenciais pipeline Python | CRÍTICO | Média | 🔴 Urgente |
| RR-01 | Sem testes para triggers | CRÍTICO | Alta | 🔴 Urgente |
| RD-01 | Payload JSONB sobrescrito | ALTO | Alta | 🔴 Urgente |
| RO-01 | Pipeline sem status visível | ALTO | Alta | 🟠 Alta |
| RS-02 | Sem proteção de rota por papel | ALTO | Baixa | 🟠 Alta |
| RR-03 | Divergência SLA frontend/banco | ALTO | Média | 🟠 Alta |
| RD-02 | Vistoria parcialmente salva | ALTO | Baixa | 🟡 Média |
| RE-01 | Haversine sem PostGIS | MÉDIO | Alta | 🟡 Média |
| RE-03 | Dashboard N queries | MÉDIO | Média | 🟡 Média |
| RS-03 | Sem rate limiting cidadão | MÉDIO | Baixa | 🟡 Média |
| RO-03 | CNES sync sem notificação | MÉDIO | Baixa | 🟡 Média |
| RD-04 | Imagens órfãs Cloudinary | MÉDIO | Baixa | 🟢 Baixa |
| RS-04 | VITE_* no bundle | MÉDIO | Desconhecida | 🟡 Média |
| RD-03 | Ciclo sem janela temporal | MÉDIO | Média | 🟢 Baixa |
| RO-04 | Web Push iOS | MÉDIO | Alta | 🟢 Baixa |

---

## Dúvidas em aberto

- Qual chave de API o pipeline Python usa para acessar o Supabase?
- Existe algum teste de integração cobrindo os triggers mais críticos?
- Houve algum incidente de perda de dados ou regressão em produção até agora?
- PostGIS está disponível/habilitado no Supabase deste projeto?
