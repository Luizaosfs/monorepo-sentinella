# 05 — Banco de Dados

## Objetivo deste documento

Descrever a estrutura do banco de dados PostgreSQL do Sentinella: tabelas, relacionamentos, migrations, triggers, views, RPCs e os principais problemas identificados.

---

## Visão geral

O banco de dados é PostgreSQL hospedado no Supabase. Toda a lógica de dados está em:

- **Tabelas** com RLS habilitado
- **Triggers** PL/pgSQL para automações críticas
- **Funções/RPCs** para operações complexas
- **Views** para consultas frequentes e calculadas
- **35+ migrations** aplicadas em sequência

---

## Entidades principais

### Hierarquia de dados

```
clientes
  └── regioes
        └── bairros
  └── planejamentos
        └── levantamentos
              └── levantamento_itens
                    └── sla_operacional
                    └── levantamento_item_evidencias
                    └── levantamento_item_status_historico
                    └── levantamento_item_recorrencia
                    └── yolo_feedback
  └── imoveis
        └── vistorias
              └── vistoria_depositos
              └── vistoria_sintomas → casos_notificados
              └── vistoria_riscos
              └── vistoria_calhas
  └── unidades_saude
        └── casos_notificados
              └── caso_foco_cruzamento (→ levantamento_itens)
  └── pluvio_operacional_run
        └── pluvio_operacional_item
              └── sla_operacional
  └── usuarios (→ auth.users)
  └── sla_config
        └── sla_config_regiao
  └── sla_feriados
  └── sla_config_audit
  └── plano_acao_catalogo
  └── canal_cidadao
  └── cliente_integracoes
  └── item_notificacoes_esus
  └── unidades_saude_sync_controle
  └── unidades_saude_sync_log
  └── push_subscriptions
  └── sentinela_risk_policy
  └── sentinela_drone_risk_config
  └── sentinela_yolo_class_config
  └── sentinela_yolo_synonym
  └── cliente_quotas
  └── voos
  └── drones
  └── levantamento_analise_ia
  └── liraa_*
  └── quarteirao_*
```

---

## Tabelas críticas detalhadas

### `clientes`

Raiz do multitenancy. Cada prefeitura é um cliente.

```
id, nome, slug, cnpj, contato_email, contato_telefone,
uf, ibge_municipio (necessários para CNES sync),
created_at
```

**Seeds automáticos ao criar cliente:** `sentinela_risk_policy`, `sentinela_drone_risk_config`, `sentinela_yolo_class_config`, `sla_config`.

---

### `levantamento_itens`

A entidade central do sistema. Cada foco identificado é um item.

```
id, levantamento_id, cliente_id,
item (nome/tipo do foco),
risco (alto | medio | baixo),
prioridade (Crítico | Urgente | Alta | Moderada | Baixa | Monitoramento),
sla_horas,
score_final (0-1 ou 0-100 — normalizar sempre),
latitude, longitude,
endereco_curto, endereco_completo,
image_url (Cloudinary),
uuid_img,
status_atendimento (pendente | em_atendimento | resolvido),
acao_aplicada, data_resolucao,
tipo_entrada (DRONE | MANUAL),
data_hora,
observacao,
checkin_lat, checkin_lng, checkin_em,
payload (jsonb — dados extras, cruzamento com casos),
created_at
```

**Triggers:** SLA automático + Recorrência + Histórico de status.

---

### `sla_operacional`

Rastreia o prazo de atendimento de cada foco.

```
id, cliente_id,
item_id (FK pluvio_operacional_item — nullable),
levantamento_item_id (FK levantamento_itens — nullable),
prioridade, sla_horas,
inicio, prazo_final,
status (pendente | em_atendimento | concluido | vencido),
violado (boolean),
escalonado (boolean),
prioridade_original,
escalonado_em,
concluido_em,
created_at
```

**Constraint crítica:** `sla_operacional_item_exclusivo` — apenas um dos dois FKs pode ser não-nulo.

---

### `sla_config`

Configuração de SLA por cliente.

```
id, cliente_id,
horas_critica, horas_urgente, horas_alta, horas_moderada, horas_baixa, horas_monitoramento,
fator_muito_alto, fator_persistencia_alta, fator_temperatura_alta,
horario_comercial (boolean),
hora_inicio_comercial, hora_fim_comercial,
created_at, updated_at
```

---

### `vistorias`

Cada visita de um agente a um imóvel.

```
id, cliente_id, imovel_id, agente_id, planejamento_id,
ciclo (1-6),
tipo_atividade (tratamento | pesquisa | liraa | ponto_estrategico),
data_visita,
status (pendente | visitado | fechado | revisita),
acesso_realizado (boolean),
motivo_sem_acesso, proximo_horario_sugerido, observacao_acesso, foto_externa_url,
moradores_qtd, gravidas, idosos, criancas_7anos,
lat_chegada, lng_chegada, checkin_em,
observacao, payload,
created_at
```

---

### `casos_notificados`

Casos de dengue/chikungunya/zika registrados por unidades de saúde.

```
id, cliente_id, unidade_saude_id, notificador_id,
doenca (dengue | chikungunya | zika | suspeito),
status (suspeito | confirmado | descartado),
data_inicio_sintomas, data_notificacao,
endereco_paciente, bairro,
latitude, longitude,
regiao_id, observacao, payload,
created_at
```

**LGPD:** SEM nome, CPF, data de nascimento ou qualquer identificador direto.

---

## Migrations — cronologia

| Migration | Data | O que faz |
|-----------|------|-----------|
| `20250301000000` | 2025-03-01 | Permite `auth_id` nulo em `usuarios` |
| `20250302000000` | 2025-03-02 | RLS em regiões |
| `20250302100000` | 2025-03-02 | RLS geral em todas as tabelas |
| `20250303000000` | 2025-03-03 | RLS + funções SLA |
| `20250306000000` | 2025-03-06 | RLS gestão de usuários |
| `20250306100000` | 2025-03-06 | Evidências + `tipo_entrada` |
| `20250306110000` | 2025-03-06 | Trigger operações → fecha SLA |
| `20250306120000` | 2025-03-06 | RLS operações e evidências |
| `20250306130000` | 2025-03-06 | View `v_historico_atendimento_local` |
| `20250306140000` | 2025-03-06 | RPC `get_meu_papel` |
| `20250306150000` | 2025-03-06 | RLS papéis/usuários |
| `20250306160000` | 2025-03-06 | Seed operador Luiz |
| `20250306170000` | 2025-03-06 | Limite de itens manuais por dia |
| `20250307100000` | 2025-03-07 | `tipo_levantamento` em planejamento |
| `20250307120000` | 2025-03-07 | Evidências por item |
| `20250307140000` | 2025-03-07 | Observação e atendimento em itens |
| `20250307160000` | 2025-03-07 | `status_atendimento` em itens |
| `20250308120000` | 2025-03-08 | Constraint 1 levantamento por dia |
| `20250308150000` | 2025-03-08 | SLA calculado via `sla_config` |
| `20250309100000` | 2025-03-09 | Trigger SLA automático pluvio |
| `20250309110000` | 2025-03-09 | `marcar_slas_vencidos` + escalonamento |
| `20250309120000` | 2025-03-09 | Tabela `sla_config_audit` |
| `20250309130000` | 2025-03-09 | SLA suporta `levantamento_item_id` |
| `20250311100000` | 2025-03-11 | Histórico de status de itens |
| `20250311110000` | 2025-03-11 | Plano de ação catálogo |
| `20250311120000` | 2025-03-11 | Recorrência automática |
| `20250311130000` | 2025-03-11 | Feriados e horário comercial |
| `20250311140000` | 2025-03-11 | Escalada iminente |
| `20250311150000` | 2025-03-11 | Checkin de item |
| `20250311160000` | 2025-03-11 | Voos, piloto, config_fonte |
| `20250311170000` | 2025-03-11 | Condições de voo |
| `20250311180000` | 2025-03-11 | SLA config por região |
| `20250311190000` | 2025-03-11 | Quotas de clientes |
| `20250311200000` | 2025-03-11 | `planejamento.regiao_id` obrigatório |
| `20250311210000` | 2025-03-11 | Correções de constraints |
| `20250313000000` | 2025-03-13 | Plano de ação por tipo |
| `20250317000000` | 2025-03-17 | Push subscriptions |
| `20250317001000` | 2025-03-17 | Canal cidadão |
| `20250317002000` | 2025-03-17 | Sprint 4 IA (yolo_feedback, analise_ia) |
| `20250318000000` | 2025-03-18 | Centro de notificações (casos + cruzamento) |
| `20250318001000` | 2025-03-18 | Vistoria de campo |
| `20250318002000` | 2025-03-18 | Acesso e calhas |
| `20250319000000` | 2025-03-19 | CNES sync |

---

## Views importantes

### `v_historico_atendimento_local`

Histórico de atendimentos agrupados por localização, com detecção de pontos recorrentes.

### `v_recorrencias_ativas`

Lista de focos com recorrências ativas (mesmo endereço/localização em 30 dias).

### `v_imovel_historico_acesso`

Histórico de tentativas de acesso por imóvel. Campos calculados:
- `pct_sem_acesso` — percentual de visitas sem acesso
- `requer_notificacao_formal` — calculado: `pct_sem_acesso > 80%` OU `proprietario_ausente=true`

**Regra:** View somente-leitura — nunca inserir diretamente.

---

## Funções PL/pgSQL

### `sla_resolve_config(p_levantamento_item_id)`

Retorna a configuração de SLA mais específica disponível para um item:
`região > cliente > padrão global`

### `sla_horas_from_config(prioridade, sla_config_row)`

Calcula horas de SLA com base na prioridade e na configuração.

### `sla_aplicar_fatores(horas_base, risco, persistencia, temperatura)`

Aplica redutores:
- `-30%` se risco = `'Muito Alto'`
- `-20%` se persistência alta
- `-10%` se temperatura > 30°C
- Mínimo absoluto: 2h

### `sla_calcular_prazo_final(inicio, sla_horas, cliente_id)`

Calcula prazo final considerando feriados e horário comercial.

### `criar_levantamento_item_manual(payload)`

RPC principal para criar itens. Valida:
1. Planejamento existe e está ativo
2. Não ultrapassou limite diário
3. Cria/reutiliza levantamento do dia
4. Insere item com todos os campos calculados

### `get_meu_papel()`

Retorna o papel do usuário autenticado no cliente ativo. Usada para RBAC.

---

## Índices

**Obrigatórios por padrão:**
```sql
CREATE INDEX ON nome_tabela (cliente_id);
```

**Índices espaciais (sem PostGIS):**
```sql
CREATE INDEX ON levantamento_itens (cliente_id, latitude, longitude);
```

**Problema:** Sem PostGIS, índices espaciais são B-tree em colunas numéricas, não índices GIST verdadeiros. Consultas de raio (haversine) fazem varredura por bbox + filtro preciso — funciona, mas não escala bem.

---

## Pontos fortes do banco

1. **RLS em todas as tabelas** — isolamento de dados garantido no nível mais seguro
2. **Triggers de auditoria** — histórico de status de itens e config de SLA rastreado
3. **Constraint de exclusividade** em `sla_operacional` (um FK ou outro, nunca os dois)
4. **Constraint de levantamento por dia** — unicidade garantida no banco, não só no frontend
5. **Recorrência automática** — trigger detecta e eleva prioridade sem intervenção humana
6. **Séd automático** de configurações ao criar cliente

---

## Problemas do banco

### P1 — Schema.sql desatualizado (ALTO)

O `schema.sql` raiz não reflete o estado atual do banco após todas as migrations. Isso torna difícil:
- Entender o estado real do banco sem rodar todas as migrations
- Identificar colunas adicionadas por migrations recentes
- Onboarding de novos desenvolvedores

**Sugestão:** Manter `schema.sql` atualizado a cada migration ou gerar automaticamente via `supabase db dump --schema`.

---

### P2 — CHECK constraints faltando (MÉDIO)

Várias regras de negócio que têm constraint no banco poderiam ter mais:
- `vistoria_depositos.qtd_com_focos <= qtd_inspecionados` — só no frontend
- Transições de `status_atendimento` — sem constraint de máquina de estados
- `ciclo` entre 1-6 — sem CHECK constraint

---

### P3 — Haversine sem PostGIS (MÉDIO)

O cruzamento caso↔foco usa haversine em PL/pgSQL puro. Com muitos itens por cliente, pode degradar performance significativamente.

**PostGIS** com `ST_DWithin` e índice GIST seria O(log n) em vez de O(n).

---

### P4 — Payload JSONB sobrescrito (ALTO)

No trigger de cruzamento caso↔foco, o `payload` do item é atualizado como:
```sql
UPDATE levantamento_itens
SET payload = jsonb_set(payload::jsonb, '{caso_notificado_proximidade}', to_jsonb(NEW.id))
```

Se múltiplos casos estiverem próximos, apenas o último `caso_id` é preservado. Os anteriores são perdidos.

**Sugestão:** Acumular em array: `payload->'casos_proximos'` como `jsonb[]`.

---

### P5 — Seed de operador específico em migration (BAIXO)

A migration `20250306160000_seed_operador_luiz.sql` insere um usuário específico. Isso é uma migration de desenvolvimento que não deveria existir em produção.

---

### P6 — Janela de 15 minutos nos SLAs vencidos (BAIXO)

A Edge Function `sla-marcar-vencidos` roda a cada 15 minutos. Entre execuções, SLAs expirados aparecem como `pendente` no banco. O frontend compensa calculando em tempo real, mas o banco fica inconsistente por até 15 minutos.

---

## Dúvidas em aberto

- Existe PostGIS habilitado no Supabase do projeto? (A migration menciona haversine por falta de PostGIS, mas Supabase geralmente oferece PostGIS)
- O `schema.sql` está sincronizado com o estado real do banco?
- Existem índices de performance criados manualmente fora das migrations?
- Qual é o volume atual de `levantamento_itens` e `sla_operacional`? (Para avaliar necessidade de PostGIS)
