# 11 — Melhorias Priorizadas

## Objetivo deste documento

Listar melhorias concretas, viáveis e priorizadas para o sistema Sentinella Web, com justificativa, esforço estimado e impacto esperado. Nenhuma melhoria proposta aqui requer reescrita total.

---

## Critérios de priorização

- **Impacto:** O quanto a melhoria beneficia usuários, reduz riscos ou melhora a manutenção
- **Esforço:** Horas de desenvolvimento estimadas (P=Pequeno ≤4h, M=Médio 1-3d, G=Grande >3d)
- **Risco de regressão:** Quão seguro é implementar sem quebrar o que funciona
- **Dependências:** O que precisa estar pronto antes

---

## 🔴 CRÍTICAS — Implementar o quanto antes

---

### M-01 — Corrigir sobrescrita do payload JSONB no trigger de cruzamento

**Problema:** Múltiplos casos próximos ao mesmo foco sobrescrevem o `payload`, preservando apenas o último.

**Solução:**
```sql
-- Em fn_cruzar_caso_com_focos, substituir:
SET payload = jsonb_set(payload::jsonb, '{caso_notificado_proximidade}', to_jsonb(NEW.id))

-- Por:
SET payload = jsonb_set(
  COALESCE(payload, '{}')::jsonb,
  '{casos_notificados_proximos}',
  COALESCE(payload->'casos_notificados_proximos', '[]')::jsonb || to_jsonb(NEW.id)
)
```

**Esforço:** P (< 1 hora — 1 migration)
**Impacto:** Alto — dados corretos em surtos com múltiplos casos
**Risco de regressão:** Baixo — mudança aditiva no payload

---

### M-02 — Auditar credenciais do pipeline Python

**Problema:** Não está documentado se o pipeline usa `service_role` ou chave de usuário.

**Ação:**
1. Inspecionar código Python e identificar qual chave é usada
2. Se `service_role`: criar usuário de serviço `sentinela_pipeline` com papel `pipeline`
3. Criar política RLS que permita ao usuário `pipeline` inserir em `levantamento_itens` e ler configs

**Esforço:** M (1-2 dias — criação de usuário, policy, teste)
**Impacto:** Crítico para segurança
**Risco de regressão:** Médio — requer teste do pipeline com novas credenciais

---

### M-03 — Adicionar CHECK constraint em vistoria_depositos

**Problema:** `qtd_com_focos <= qtd_inspecionados` validado apenas no frontend.

**Solução:**
```sql
ALTER TABLE vistoria_depositos
ADD CONSTRAINT chk_focos_nao_excedem_inspecionados
CHECK (qtd_com_focos <= qtd_inspecionados);
```

**Esforço:** P (< 1 hora — 1 migration)
**Impacto:** Médio — garante integridade de dados epidemiológicos
**Risco de regressão:** Baixo — constraint nova, sem dados inválidos existentes (verificar antes)

---

---

## 🟠 ALTAS — Implementar na próxima sprint

---

### M-04 — Centralizar normalizeScore em lib/scoreUtils.ts

**Problema:** `normalizeScore()` duplicada em `ItemDetailPanel.tsx` e `ItemScoreBadge.tsx`.

**Solução:**
```typescript
// src/lib/scoreUtils.ts
export function normalizeScore(raw: number | null | undefined): number | null {
  if (raw == null) return null;
  return raw > 1 ? raw / 100 : raw;
}

export function getScoreConfig(normalized: number | null) {
  if (normalized == null) return { label: 'Sem score', color: 'gray' };
  if (normalized >= 0.85) return { label: 'Muito alta', color: 'red' };
  if (normalized >= 0.65) return { label: 'Alta', color: 'orange' };
  if (normalized >= 0.45) return { label: 'Média', color: 'amber' };
  return { label: 'Baixa', color: 'green' };
}
```

**Esforço:** P (2-3 horas — criar arquivo, atualizar imports)
**Impacto:** Médio — evita divergência futura
**Risco de regressão:** Baixo

---

### M-05 — Adicionar RoleGuard nas rotas admin

**Problema:** Sem verificação de papel antes de renderizar rotas `/admin/*`.

**Solução:**
```typescript
// src/components/RoleGuard.tsx
function RoleGuard({ roles, children }: { roles: string[], children: ReactNode }) {
  const { papel } = useClienteAtivo();
  if (!roles.includes(papel)) return <Navigate to="/dashboard" />;
  return <>{children}</>;
}

// Em App.tsx
<Route path="/admin/*" element={
  <RoleGuard roles={['admin', 'supervisor']}>
    <AdminLayout />
  </RoleGuard>
} />
```

**Esforço:** P (3-4 horas)
**Impacto:** Alto — segurança de interface
**Risco de regressão:** Baixo

---

### M-06 — Status de processamento do pipeline no levantamento

**Problema:** Gestor não sabe se o pipeline está processando ou falhou.

**Solução:**
```sql
-- migration
ALTER TABLE levantamentos
ADD COLUMN status_processamento text DEFAULT 'aguardando'
CHECK (status_processamento IN ('aguardando', 'processando', 'concluido', 'erro'));
ADD COLUMN processamento_erro text;
ADD COLUMN processamento_em timestamptz;
```

Pipeline atualiza este campo. Frontend exibe badge no levantamento.

**Esforço:** M (1-2 dias — migration + frontend + pipeline)
**Impacto:** Alto — visibilidade operacional crítica
**Risco de regressão:** Baixo — campo aditivo

---

### M-07 — Atualizar schema.sql

**Problema:** `schema.sql` desatualizado.

**Solução:**
```bash
supabase db dump --schema > schema.sql
```

Automatizar via CI/CD ou script pós-migration.

**Esforço:** P (1 hora + script)
**Impacto:** Médio — documentação e onboarding
**Risco de regressão:** Zero

---

### M-08 — Rate limiting no Canal Cidadão

**Problema:** Sem proteção contra spam de denúncias.

**Solução:** Na Edge Function/RPC do canal cidadão, verificar contagem de denúncias por IP nas últimas 24h.

```sql
-- Tabela auxiliar ou campo em canal_cidadao
CREATE TABLE canal_cidadao_rate_limit (
  ip_hash text PRIMARY KEY,
  contagem int DEFAULT 1,
  primeira_em timestamptz DEFAULT now(),
  ultima_em timestamptz DEFAULT now()
);
```

**Esforço:** M (1 dia)
**Impacto:** Médio — proteção contra abuso
**Risco de regressão:** Baixo

---

---

## 🟡 MÉDIAS — Planejar para próximo ciclo

---

### M-09 — Dividir api.ts em módulos por domínio

**Problema:** 2.831 linhas em um arquivo.

**Solução:**
```
src/services/api/
├── levantamentos.ts
├── sla.ts
├── vistoria.ts
├── casos.ts
├── cloudinary.ts
├── quotas.ts
├── usuarios.ts
├── drones.ts
├── pluvio.ts
├── integracoes.ts
├── admin.ts
└── index.ts (re-exporta api unificado)
```

**Esforço:** G (3-4 dias — refatoração cuidadosa com testes após cada módulo)
**Impacto:** Alto na manutenção, baixo na funcionalidade
**Risco de regressão:** Médio — requer revisão de todos os imports

---

### M-10 — Criar suíte de testes para fluxos críticos

**Problema:** Sem testes automatizados.

**Prioridade de criação:**
1. `calcularSlaHoras()` — unitário (Vitest)
2. `normalizeScore()` — unitário
3. Trigger de SLA automático — integração
4. Multitenancy (usuário A não vê dados de B) — integração
5. Fluxo de atendimento completo — E2E (Playwright)

**Esforço:** G (1-2 semanas para cobertura mínima)
**Impacto:** Crítico para segurança de evoluções
**Risco de regressão:** Zero

---

### M-11 — Habilitar PostGIS para cruzamento geoespacial

**Problema:** Haversine manual sem índice GIST é O(n) por query.

**Solução:**
```sql
-- Habilitar PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;

-- Adicionar coluna geográfica
ALTER TABLE levantamento_itens
ADD COLUMN geom geography(POINT, 4326)
GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)) STORED;

-- Índice GIST
CREATE INDEX ON levantamento_itens USING GIST (geom);

-- Atualizar trigger de cruzamento
-- ST_DWithin(NEW.geom, li.geom, 300) em vez de haversine
```

**Esforço:** M (1-2 dias — verificar se PostGIS disponível, migration, atualizar trigger)
**Impacto:** Médio agora, Alto com escala
**Risco de regressão:** Médio — alterar trigger crítico

---

### M-12 — RPC de dashboard summary

**Problema:** 14+ queries simultâneas ao carregar dashboard.

**Solução:**
```sql
CREATE OR REPLACE FUNCTION dashboard_summary(p_cliente_id uuid)
RETURNS jsonb AS $$
SELECT jsonb_build_object(
  'itens_pendentes', (SELECT count(*) FROM levantamento_itens WHERE cliente_id = p_cliente_id AND status_atendimento = 'pendente'),
  'sla_vencidos', (SELECT count(*) FROM sla_operacional WHERE cliente_id = p_cliente_id AND status = 'vencido'),
  'casos_semana', (SELECT count(*) FROM casos_notificados WHERE cliente_id = p_cliente_id AND created_at > now() - interval '7 days'),
  -- ... outros KPIs
)
$$ LANGUAGE sql SECURITY DEFINER;
```

**Esforço:** M (1-2 dias)
**Impacto:** Médio — UX do dashboard e performance
**Risco de regressão:** Baixo — novo endpoint, não substitui os existentes imediatamente

---

### M-13 — Adicionar janela temporal na regra de 3 tentativas

**Problema:** Trigger conta tentativas sem acesso ao longo de toda a vida do imóvel.

**Solução:**
```sql
-- No trigger trg_atualizar_perfil_imovel, substituir:
WHERE imovel_id = NEW.imovel_id AND acesso_realizado = false

-- Por:
WHERE imovel_id = NEW.imovel_id
  AND acesso_realizado = false
  AND created_at > now() - interval '60 days'
```

**Esforço:** P (1-2 horas — 1 migration)
**Impacto:** Baixo — melhora qualidade dos dados
**Risco de regressão:** Baixo

---

### M-14 — ESLint rules customizadas para proteções de multitenancy

**Problema:** Sem detecção automática de desvios.

**Solução:** Plugin ESLint customizado ou `eslint-plugin-no-restricted-syntax` para:
- Detectar `supabase.from(...)` fora de `src/services/`
- Detectar `clienteId` não derivado de `useClienteAtivo`

**Esforço:** M (1 dia)
**Impacto:** Baixo agora, Alto como prevenção
**Risco de regressão:** Zero

---

## 🟢 BAIXAS — Backlog para quando houver espaço

---

### M-15 — Dividir database.ts por domínio

Similar ao M-09 para os tipos TypeScript.

**Esforço:** M | **Impacto:** Baixo | **Prioridade:** Baixa

---

### M-16 — Decomposição de ItemDetailPanel

Separar em sub-componentes: `ItemScoreSection`, `ItemSlaSection`, `ItemCasosSection`, etc.

**Esforço:** M | **Impacto:** Baixo | **Prioridade:** Baixa (refatorar na próxima feature)

---

### M-17 — React Context para formulário de vistoria

Substituir prop drilling no stepper de vistoria por Context API.

**Esforço:** M | **Impacto:** Baixo | **Prioridade:** Baixa

---

### M-18 — Cleanup periódico de assets órfãos no Cloudinary

Script/Edge Function que compare `image_url` no banco com assets no Cloudinary.

**Esforço:** M | **Impacto:** Baixo (custo) | **Prioridade:** Baixa

---

## Resumo executivo de melhorias

| ID | Melhoria | Esforço | Impacto | Prioridade |
|----|---------|---------|---------|-----------|
| M-01 | Fix payload JSONB trigger | P | Alto | 🔴 Agora |
| M-02 | Auditar credenciais Python | M | Crítico | 🔴 Agora |
| M-03 | CHECK constraint depositos | P | Médio | 🔴 Agora |
| M-04 | Centralizar normalizeScore | P | Médio | 🟠 Sprint |
| M-05 | RoleGuard nas rotas | P | Alto | 🟠 Sprint |
| M-06 | Status processamento pipeline | M | Alto | 🟠 Sprint |
| M-07 | Atualizar schema.sql | P | Médio | 🟠 Sprint |
| M-08 | Rate limiting canal cidadão | M | Médio | 🟠 Sprint |
| M-09 | Dividir api.ts | G | Alto (manutenção) | 🟡 Ciclo |
| M-10 | Suíte de testes | G | Crítico | 🟡 Ciclo |
| M-11 | PostGIS para cruzamento | M | Alto (escala) | 🟡 Ciclo |
| M-12 | RPC dashboard summary | M | Médio | 🟡 Ciclo |
| M-13 | Janela temporal 3 tentativas | P | Baixo | 🟡 Ciclo |
| M-14 | ESLint customizado | M | Médio | 🟡 Ciclo |
| M-15 | Dividir database.ts | M | Baixo | 🟢 Backlog |
| M-16 | Decompor ItemDetailPanel | M | Baixo | 🟢 Backlog |
| M-17 | Context formulário vistoria | M | Baixo | 🟢 Backlog |
| M-18 | Cleanup Cloudinary órfãos | M | Baixo | 🟢 Backlog |
