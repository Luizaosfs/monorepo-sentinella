# 09 — Dívida Técnica

## Objetivo deste documento

Identificar, catalogar e priorizar toda a dívida técnica do projeto: código legado, abstrações prematuras ou ausentes, arquivos grandes, duplicidade, acoplamento excessivo e inconsistências técnicas.

---

## O que é dívida técnica?

Dívida técnica é o custo futuro de trabalho extra causado por decisões de design que foram tomadas por conveniência imediata — às vezes conscientemente, às vezes por evolução natural do projeto.

Ela não é necessariamente "código ruim". É código que funcionou bem para o tamanho/equipe de ontem, mas que começa a impedir o crescimento de amanhã.

---

## DT-01 — api.ts monolítico (CRÍTICO)

**O problema:** `src/services/api.ts` tem 2.831 linhas e cresce a cada sprint. É um único arquivo com 20+ namespaces de domínios completamente diferentes (SLA, vistoria, Cloudinary, drones, quota, CNES...).

**Por que surgiu:** Arquitetura de "arquivo de serviço único" que faz sentido com 200 linhas, mas não com 3.000.

**Impacto:**
- Conflitos de merge em equipe (todos mexem no mesmo arquivo)
- TypeScript Language Server mais lento ao analisar o arquivo
- Dificuldade de encontrar métodos (mesmo com Ctrl+F)
- Risco de duplicar métodos sem perceber
- Impossibilidade de fazer code splitting por domínio

**Solução sugerida:**
```
src/services/
├── api/
│   ├── levantamentos.ts
│   ├── sla.ts
│   ├── vistoria.ts
│   ├── casos.ts
│   ├── cloudinary.ts
│   ├── quotas.ts
│   ├── admin.ts
│   └── ...
└── api.ts (re-exporta objeto api unificado via index)
```

**Esforço:** Médio (refatoração segura — mudança apenas na estrutura, não no comportamento)
**Prioridade:** Alta

---

## DT-02 — database.ts com 1.410 linhas (ALTO)

**O problema:** `src/types/database.ts` tem 1.410 linhas com 50+ interfaces. Tudo em um arquivo.

**Impacto:**
- Difícil de navegar
- Imports globais desnecessários quando apenas um tipo é necessário
- Tendência de crescer sem controle

**Solução sugerida:**
```
src/types/
├── levantamento.ts
├── sla.ts (já existe — manter)
├── vistoria.ts
├── casos.ts
├── usuario.ts
├── drone.ts
└── index.ts (re-exporta tudo)
```

**Esforço:** Médio
**Prioridade:** Média

---

## DT-03 — Regras de negócio duplicadas entre frontend e banco (CRÍTICO)

**O problema:** Várias regras de negócio importantes estão implementadas tanto em TypeScript (frontend/sla.ts) quanto em PL/pgSQL (banco). A mais crítica é o cálculo de SLA:

| Regra | Frontend | Banco |
|-------|---------|-------|
| Prazos base por prioridade | `SLA_RULES` em sla.ts | `sla_config` table |
| Redutores climáticos | `calcularSlaHoras()` | `sla_aplicar_fatores()` |
| Status visual SLA | `getSlaVisualStatus()` | campo `status` |
| Normalização de score YOLO | `normalizeScore()` duplicada em 2 arquivos | — |

**Por que surgiu:** Frontend precisa de cálculo local para exibição sem fazer query. Banco precisa de cálculo para garantir integridade. Sem sincronismo automatizado entre os dois.

**Impacto:** Se alguém muda os coeficientes em `sla.ts`, o banco continua com os valores antigos. Divergência silenciosa.

**Solução sugerida:**
- `sla.ts` deve ser exclusivamente para **exibição/UX** (cálculo visual, nada de autoridade)
- O banco é a **única fonte de verdade** para `sla_horas` e `prazo_final`
- Documentar claramente: "Se há discrepância entre o que sla.ts calcula e o que o banco retorna, o banco está certo"
- `normalizeScore` centralizada em `src/lib/scoreUtils.ts`

**Esforço:** Baixo (documentação) + Médio (refatoração)
**Prioridade:** Alta

---

## DT-04 — Sem testes automatizados robustos (ALTO)

**O problema:** Playwright e Vitest estão nas dependências mas sem evidência de suíte de testes cobrindo fluxos críticos. Um projeto desta complexidade (múltiplos triggers, RPCs, fluxos offline, estados de SLA) precisa de testes.

**Impacto:**
- Cada deploy é um risco — sem rede de segurança
- Regressões em fluxos críticos (SLA, multitenancy) só descobertas em produção
- Dificuldade de refatorar com confiança

**O que deve ser testado (prioridade):**
1. `calcularSlaHoras()` e `getSlaVisualStatus()` — unitário
2. `normalizeScore()` — unitário
3. Fluxo de criação de item manual — integração
4. Fluxo de atendimento de operador — E2E
5. Isolamento de multitenancy — integração

**Esforço:** Alto
**Prioridade:** Alta

---

## DT-05 — Schema.sql desatualizado (MÉDIO)

**O problema:** O arquivo `schema.sql` raiz não reflete o estado atual do banco após 35+ migrations. Ninguém sabe o estado real do banco sem rodar todas as migrations.

**Impacto:**
- Onboarding de novos desenvolvedores lento
- Difícil depurar problemas sem schema atualizado
- Documentação imprecisa

**Solução:**
```bash
supabase db dump --schema > schema.sql
```

Executar após cada migration e commitar o resultado.

**Esforço:** Baixo
**Prioridade:** Média

---

## DT-06 — ItemDetailPanel.tsx com responsabilidades excessivas (MÉDIO)

**O problema:** O componente `ItemDetailPanel.tsx` tem responsabilidades demais:
- Score YOLO + normalização
- Timeline de SLA
- Casos notificados próximos
- Feedback de falso positivo
- Notificação e-SUS
- Assistente de voz
- Histórico de recorrência
- Ações de atendimento

**Impacto:** Componente difícil de manter, testar e evoluir. Qualquer novo requisito entra aqui por "facilidade".

**Solução sugerida:** Decomposição em sub-componentes com responsabilidades únicas:
```
ItemDetailPanel/
├── ItemScoreSection.tsx
├── ItemSlaSection.tsx
├── ItemCasosSection.tsx
├── ItemEvidenciasSection.tsx
├── ItemAcoesSection.tsx
└── ItemDetailPanel.tsx (orquestrador)
```

**Esforço:** Médio
**Prioridade:** Baixa (funciona; refatorar quando houver nova funcionalidade aqui)

---

## DT-07 — Dashboard com 14+ queries simultâneas (MÉDIO)

**O problema:** Cada widget do dashboard faz sua própria query ao Supabase ao montar. Com 14 widgets, isso são 14+ queries em paralelo ao carregar a página.

**Impacto:**
- Múltiplas conexões ao banco simultâneas
- Experiência fragmentada (widgets carregando em momentos diferentes)
- Difícil de otimizar com prefetch

**Solução sugerida:**
- Criar endpoint/RPC `dashboard_summary` que retorna todos os KPIs em uma única query
- Ou usar `useQueries` do React Query para melhor controle de paralelismo

**Esforço:** Médio
**Prioridade:** Média

---

## DT-08 — Migration de seed de usuário específico (BAIXO)

**O problema:** `20250306160000_seed_operador_luiz.sql` insere um usuário específico de desenvolvimento. Provavelmente específico do ambiente de dev e não de produção.

**Impacto:** Ambiente de produção pode ter usuário de teste ativo.

**Solução:** Verificar se migration foi executada em produção. Se sim, remover o usuário de produção. Migration de seed de dev não deveria existir no repositório principal.

**Esforço:** Baixo
**Prioridade:** Média (segurança)

---

## DT-09 — OperadorFormularioVistoria com estado complexo sem Context (MÉDIO)

**O problema:** O formulário de vistoria em 5 etapas gerencia estado compartilhado entre etapas via props e `useState` no componente pai. Sem React Context ou state machine.

**Impacto:**
- Prop drilling entre pai e filhos
- Difícil de testar etapas isoladamente
- Qualquer nova etapa ou campo aumenta a complexidade do pai

**Solução sugerida:** React Context para estado do formulário + validação por etapa centralizada.

**Esforço:** Médio
**Prioridade:** Baixa (funciona; refatorar quando houver mudança no fluxo)

---

## DT-10 — Payload JSONB como campo de dados não estruturados (MÉDIO)

**O problema:** Campos `payload` (jsonb) em `levantamento_itens`, `vistorias` e `casos_notificados` são usados para guardar dados extras sem schema definido.

**Impacto:**
- Sem validação de estrutura no banco
- Queries em campos jsonb são mais lentas que em colunas tipadas
- Um bug (RULE-23 do `07-regras-de-negocio.md`) sobrescreve casos no payload

**Solução:** Para dados frequentemente consultados (ex: `caso_notificado_proximidade`), criar coluna tipada. Manter payload apenas para dados realmente ad-hoc.

**Esforço:** Médio (migration para normalizar)
**Prioridade:** Média

---

## DT-11 — Falta de ESLint rules para proteções críticas (BAIXO)

**O problema:** Não há regras de lint customizadas para:
- Detectar `supabase.from(...)` em componentes de página (deveria ser apenas em api.ts)
- Detectar `clienteId` derivado fora de `useClienteAtivo`
- Detectar queries sem `.eq('cliente_id', ...)` (básico de multitenancy)

**Impacto:** Desvios de padrão passam pela revisão de código sem alerta automatizado.

**Esforço:** Baixo
**Prioridade:** Média

---

## DT-12 — docs/ com estrutura duplicada e desatualizada (BAIXO)

**O problema:** A pasta `docs/` tem múltiplos arquivos com finalidades sobrepostas:
- `00-project-brain.md` aponta para arquivos que não existem (`docs/arquitetura.md` vs `ARQUITETURA.MD`)
- `MODELO-DADOS.MD` está desatualizado em relação ao estado real do banco
- `02-glossario.md` tem termos muito superficiais
- Mistura de arquivos em maiúsculas e minúsculas (inconsistência de nomenclatura)

**Impacto:** Documentação perde credibilidade como fonte de verdade se estiver desatualizada.

**Esforço:** Baixo
**Prioridade:** Alta (este trabalho atual está resolvendo isso)

---

## Resumo por prioridade

| ID | Problema | Prioridade | Esforço |
|----|---------|-----------|---------|
| DT-01 | api.ts monolítico | CRÍTICA | Médio |
| DT-03 | Regras duplicadas banco/frontend | CRÍTICA | Médio |
| DT-04 | Sem testes automatizados | ALTA | Alto |
| DT-02 | database.ts enorme | ALTA | Médio |
| DT-05 | Schema.sql desatualizado | MÉDIA | Baixo |
| DT-07 | Dashboard com N queries | MÉDIA | Médio |
| DT-08 | Migration de usuário dev | MÉDIA | Baixo |
| DT-11 | Sem ESLint rules customizadas | MÉDIA | Baixo |
| DT-06 | ItemDetailPanel supercarregado | BAIXA | Médio |
| DT-09 | Formulário sem Context | BAIXA | Médio |
| DT-10 | Overuse de payload JSONB | BAIXA | Médio |
| DT-12 | Docs desatualizados | BAIXA | Baixo |

---

## O que NÃO é dívida técnica aqui

Para ser justo na análise:

1. **Supabase como backend** — decisão arquitetural válida para o estágio atual do produto
2. **Tailwind + Radix UI** — escolhas modernas e bem executadas
3. **React Query com cache granular** — implementação acima da média
4. **Triggers para SLA e recorrência** — correto colocar regras críticas no banco
5. **Multitenancy via RLS** — implementado corretamente
6. **Offline-first com IndexedDB** — bem pensado para a realidade dos agentes
