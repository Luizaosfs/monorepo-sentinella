# 13 — Padrões de Desenvolvimento

## Objetivo deste documento

Documentar os padrões técnicos estabelecidos no projeto, para que qualquer desenvolvedor possa contribuir de forma consistente, sem introduzir inconsistências ou quebrar convenções.

---

## Regra fundamental

> **Antes de criar qualquer código, verificar se o tipo, hook ou método já existe.**

---

## Convenções de nomenclatura

```
Componentes:     PascalCase     → src/components/
Hooks:           camelCase "use"→ src/hooks/
Serviços:        camelCase      → src/services/api.ts
Tipos:           PascalCase     → src/types/database.ts
Seeds:           seedDefault*   → src/lib/
Imports:         alias @/       → import { api } from '@/services/api'
Edge Functions:  kebab-case     → supabase/functions/nome-da-function/
Migrations:      yyyymmddNNNNNN → supabase/migrations/
```

---

## Padrão de hook de query

**Arquivo:** `src/hooks/queries/useNomeFuncionalidade.ts`

```typescript
import { useQuery } from '@tanstack/react-query';
import { api } from '@/services/api';
import { STALE } from '@/lib/queryConfig';

export function useNomeFuncionalidade(clienteId: string | null | undefined) {
  return useQuery({
    queryKey: ['nome-funcionalidade', clienteId],
    queryFn: () => api.nomeFuncionalidade.list(clienteId!),
    enabled: !!clienteId,
    staleTime: STALE.MEDIUM,  // sempre usar constante, nunca número literal
  });
}
```

### Constantes STALE disponíveis

```typescript
// src/lib/queryConfig.ts
export const STALE = {
  LIVE: 0,            // sempre refetch (SLA crítico, alertas)
  VERY_SHORT: 30_000, // 30s (painel SLA com polling)
  SHORT: 60_000,      // 1min (casos, operações ativas)
  RECENT: 120_000,    // 2min (quotas, evidências)
  MEDIUM: 180_000,    // 3min (padrão geral)
  MODERATE: 300_000,  // 5min (pluvio, planejamentos)
  MAP: 600_000,       // 10min (dados cartográficos)
  EXTENDED: 900_000,  // 15min (condições de voo)
  STATIC: 1_800_000,  // 30min (configurações estáveis)
  SESSION: Infinity,  // enquanto a sessão durar (policies de risco)
};
```

---

## Padrão de método em api.ts

```typescript
// Em src/services/api.ts, dentro do objeto api
nomeFuncionalidade: {
  list: async (clienteId: string): Promise<TipoRetorno[]> => {
    const { data, error } = await supabase
      .from('nome_tabela')
      .select('*')
      .eq('cliente_id', clienteId)           // OBRIGATÓRIO — multitenancy
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  create: async (payload: Omit<TipoRetorno, 'id' | 'created_at'>): Promise<TipoRetorno> => {
    const { data, error } = await supabase
      .from('nome_tabela')
      .insert(payload)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  update: async (id: string, payload: Partial<TipoRetorno>): Promise<void> => {
    const { error } = await supabase
      .from('nome_tabela')
      .update(payload)
      .eq('id', id);
    if (error) throw error;
  },

  remove: async (id: string): Promise<void> => {
    const { error } = await supabase
      .from('nome_tabela')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },
},
```

### Regras obrigatórias em api.ts

1. **Sempre filtrar por `cliente_id`** — sem exceção
2. **Sempre tratar o erro** com `if (error) throw error`
3. **Sempre retornar `data || []`** em queries de lista (nunca retornar null)
4. **Nunca colocar lógica de negócio** — apenas queries e calls
5. **Usar `.select().single()`** em inserts que precisam retornar o registro criado

---

## Padrão de migration SQL

```sql
-- ============================================================
-- Migration: 20260326000000_descricao_clara.sql
-- Objetivo: Descreva aqui o que esta migration faz
-- ============================================================

-- 1. Criar tabela
CREATE TABLE nome_tabela (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  cliente_id  uuid        NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  nome        text        NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- 2. Habilitar RLS (SEMPRE)
ALTER TABLE nome_tabela ENABLE ROW LEVEL SECURITY;

-- 3. Política de isolamento por cliente (padrão)
CREATE POLICY "isolamento_por_cliente" ON nome_tabela
  USING (cliente_id IN (
    SELECT cliente_id FROM usuarios WHERE auth_id = auth.uid()
  ));

-- 4. Índice obrigatório em cliente_id
CREATE INDEX idx_nome_tabela_cliente_id ON nome_tabela (cliente_id);

-- 5. Trigger de updated_at (se necessário)
CREATE TRIGGER trg_nome_tabela_updated_at
  BEFORE UPDATE ON nome_tabela
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

### Regras de migrations

1. **Nome de arquivo:** `yyyymmddNNNNNN_descricao_em_snake_case.sql`
2. **RLS obrigatório** em toda nova tabela
3. **Índice em `cliente_id`** obrigatório
4. **Comentário de objetivo** no topo
5. **Testar em ambiente local** antes de aplicar em produção
6. **Atualizar `schema.sql`** após aplicar

---

## Padrão de multitenancy

### Em componentes e hooks

```typescript
// ✅ CORRETO
import { useClienteAtivo } from '@/hooks/useClienteAtivo';

function MeuComponente() {
  const { clienteId } = useClienteAtivo();
  const { data } = useMinhaQuery(clienteId);
  // ...
}
```

```typescript
// ❌ ERRADO — nunca derivar clienteId de outra forma
const clienteId = localStorage.getItem('clienteId'); // NUNCA
const clienteId = supabase.auth.getUser().id;        // NUNCA
```

### Em api.ts

```typescript
// ✅ CORRETO
const { data } = await supabase
  .from('levantamento_itens')
  .select('*, levantamento:levantamentos!inner(*)')
  .eq('levantamento.cliente_id', clienteId);

// ❌ ERRADO — sem filtro de cliente
const { data } = await supabase.from('levantamento_itens').select('*');
```

---

## Padrão de tipo TypeScript

```typescript
// src/types/database.ts
export interface NomeDaEntidade {
  id: string;                        // sempre uuid como string
  cliente_id: string;                // sempre presente
  created_at: string;                // ISO string do banco
  updated_at?: string;               // opcional se não há trigger
  // ... campos específicos
}

// Para tipos de status, usar union type
export type StatusDaEntidade = 'pendente' | 'em_andamento' | 'concluido';

// Para enums de UI, usar labels correspondentes
export const STATUS_LABELS: Record<StatusDaEntidade, string> = {
  pendente: 'Pendente',
  em_andamento: 'Em andamento',
  concluido: 'Concluído',
};
```

---

## Padrão de componente de página

```typescript
// src/pages/admin/AdminNomeFuncionalidade.tsx
import { useClienteAtivo } from '@/hooks/useClienteAtivo';
import { useNomeFuncionalidade } from '@/hooks/queries/useNomeFuncionalidade';

export default function AdminNomeFuncionalidade() {
  const { clienteId } = useClienteAtivo();  // SEMPRE aqui
  const { data, isLoading, error } = useNomeFuncionalidade(clienteId);

  if (isLoading) return <LoadingState />;
  if (error) return <ErrorState error={error} />;

  return (
    <AdminPageHeader title="Nome da Funcionalidade" />
    // ...
  );
}
```

### Regras de componentes de página

1. **Nunca acessar `supabase` diretamente** — sempre via api.ts
2. **Sempre usar `useClienteAtivo`** para obter clienteId
3. **Tratar loading e error** antes de renderizar dados
4. **Não colocar lógica de negócio no componente** — mover para hooks ou api.ts

---

## Padrão de invalidação de cache

```typescript
// Após mutations, invalidar queries relacionadas
import { useQueryClient } from '@tanstack/react-query';

const queryClient = useQueryClient();

// Ao criar/atualizar item:
queryClient.invalidateQueries({ queryKey: ['levantamento-itens', clienteId] });
queryClient.invalidateQueries({ queryKey: ['sla-operacional', clienteId] });
```

**Arquivo centralizado:** `src/lib/invalidateAtendimentoQueries.ts` — usar para invalidações complexas que afetam múltiplas queries.

---

## Padrão de seed de configuração

```typescript
// src/lib/seedDefaultNomeFuncionalidade.ts
import { supabase } from '@/lib/supabase';

export async function seedDefaultNomeFuncionalidade(clienteId: string): Promise<void> {
  const { error } = await supabase
    .from('nome_tabela')
    .insert({
      cliente_id: clienteId,
      // ... valores padrão
    });
  if (error) throw error;
}
```

---

## Padrão de score YOLO — normalização obrigatória

```typescript
// src/lib/scoreUtils.ts (criar este arquivo — centralizar aqui)

export function normalizeScore(raw: number | null | undefined): number | null {
  if (raw == null) return null;
  return raw > 1 ? raw / 100 : raw;
}

export function getScoreConfig(normalized: number | null) {
  if (normalized == null) return null;
  if (normalized >= 0.85) return { label: 'Muito alta', color: 'destructive', value: normalized };
  if (normalized >= 0.65) return { label: 'Alta', color: 'orange', value: normalized };
  if (normalized >= 0.45) return { label: 'Média', color: 'amber', value: normalized };
  return { label: 'Baixa', color: 'success', value: normalized };
}
```

**Regra:** Nunca exibir `score_final` bruto. Sempre normalizar primeiro.

---

## Regras de negócio — onde colocar

| Tipo de regra | Onde deve estar |
|--------------|----------------|
| Validação de formato (email, telefone) | Frontend (Zod/yup) |
| Validação de negócio simples (campo obrigatório) | Frontend + banco (NOT NULL) |
| Regra crítica de integridade (1 levantamento/dia) | Banco (constraint/trigger) |
| Cálculo de prazo SLA | Banco (função PL/pgSQL) + frontend apenas para exibição |
| Cruzamento geoespacial | Banco (trigger) — nunca no frontend |
| Normalização de score | Frontend (scoreUtils.ts) — banco recebe bruto |
| Ciclo epidemiológico | Frontend (calculado) + banco (persistido no campo ciclo) |

---

## O que fazer ao receber uma tarefa de implementação

1. **Identificar o domínio** (levantamento? sla? drone? operador? pluvio?)
2. **Verificar se o tipo já existe** em `src/types/database.ts`
3. **Verificar se o método já existe** em `src/services/api.ts`
4. Se nova tabela necessária: **propor migration SQL com RLS** antes de escrever código
5. **Criar ou estender** o método em `api.ts`
6. **Criar o hook** em `src/hooks/queries/`
7. **Implementar o componente** consumindo o hook
8. Para configs de novo cliente: **criar seed** em `src/lib/seedDefault*.ts`
9. **Nunca acessar supabase diretamente** em componentes de página
10. **Atualizar schema.sql** após nova migration

---

## Checklist de code review

- [ ] Filtro `cliente_id` presente em todas as queries
- [ ] Hook `useClienteAtivo` usado para obter clienteId
- [ ] Constante `STALE.*` usada (sem número literal)
- [ ] `if (error) throw error` em todos os métodos de api.ts
- [ ] `data || []` em métodos de lista
- [ ] RLS habilitado em nova tabela
- [ ] Índice em `cliente_id` na nova tabela
- [ ] Tipos TypeScript atualizados em `database.ts`
- [ ] Score normalizado antes de exibir
- [ ] Loading e error states tratados no componente
