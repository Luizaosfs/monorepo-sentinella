# 07 — Regras de Negócio

## Objetivo deste documento

Catalogar, analisar e comentar todas as regras de negócio do sistema, indicando onde cada regra está implementada, se está duplicada, se tem riscos e qual é a recomendação.

---

## Onde vivem as regras de negócio

O sistema tem regras espalhadas em 5 lugares diferentes:

| Local | Exemplos |
|-------|---------|
| **Frontend (TypeScript)** | Normalização de score YOLO, cálculo visual de SLA, validação de depósitos |
| **api.ts** | Filtros de multitenancy, construção de queries |
| **sla.ts** | Cálculo de prazos, redutores climáticos, status visual |
| **Triggers PL/pgSQL** | SLA automático, recorrência, cruzamento caso↔foco, auditoria |
| **RPCs PL/pgSQL** | Criação de item manual com validações, cálculo de config de SLA |
| **Edge Functions** | Triagem IA, sync CNES, envio de push |

**Risco:** Regras duplicadas em camadas diferentes podem divergir. Uma mudança em `sla.ts` não se propaga automaticamente para os cálculos no banco.

---

## MÓDULO: PLANEJAMENTO

### RULE-01 — Tipos permitidos: DRONE ou MANUAL

**Onde:** `levantamento_itens.tipo_entrada` (DB) + `LevantamentoItem.tipo_entrada` (TypeScript)

**Regra:** Um planejamento define o tipo de operação. Drone = imagens do pipeline Python. Manual = operador em campo.

**Risco:** Itens sem `tipo_entrada` não disparam a lógica correta de score/SLA.

**Status:** ✅ Implementado com constraint no banco.

---

### RULE-02 — Um levantamento por dia por planejamento

**Onde:** Migration `20250308120000` — constraint unique `(planejamento_id, date(data_voo), tipo_entrada)`

**Regra:** Garante que o mesmo planejamento não gere dois levantamentos no mesmo dia.

**Risco:** Pode ser contornado via INSERT direto no banco (fora de RLS em modo service_role).

**Status:** ✅ Implementado com constraint no banco.

---

### RULE-03 — regiao_id obrigatório para SLA por região

**Onde:** Migration `20250311200000` + trigger `sla_resolve_config()`

**Regra:** Planejamentos sem `regiao_id` usam config padrão do cliente para SLA (sem customização por região).

**Risco:** Gestor pode criar planejamento sem região e não perceber que o SLA calculado é o genérico.

**Sugestão:** Validar presença de `regiao_id` no formulário de criação de planejamento.

---

### RULE-04 — Quota de voos verificada antes de criar

**Onde:** Frontend (`AdminVoos.tsx`) via `api.quotas.verificar`

**Regra:** Antes de criar voo DRONE, verifica se o cliente tem quota disponível.

**Risco:** Verificação apenas no frontend. Insert direto ou via API bypassa a quota.

**Sugestão:** Adicionar check de quota no trigger ou RPC de criação de voo.

---

## MÓDULO: LEVANTAMENTO

### RULE-05 — Levantamento deve ter planejamento_id

**Onde:** FK obrigatório em `levantamentos.planejamento_id`

**Regra:** Todo levantamento pertence a um planejamento. Sem isso, a rastreabilidade é quebrada.

**Status:** ✅ FK constraint garante isso.

---

### RULE-06 — config_fonte rastreia origem da config YOLO

**Onde:** `levantamentos.config_fonte` — valores: `'supabase'` ou `'local_json:yolo,risk'`

**Regra:** Se o pipeline Python usou configuração do Supabase ou do JSON local como fallback.

**Risco:** Fallback para JSON local pode produzir classificações desatualizadas sem alerta claro.

---

## MÓDULO: LEVANTAMENTO_ITEM

### RULE-07 — Ciclo de vida: pendente → em_atendimento → resolvido

**Onde:** `StatusAtendimento` em `database.ts` + `api.itens.updateAtendimento`

**Regra:** Transições válidas de status. Não há transição direta de `pendente` para `resolvido`.

**Risco:** Sem constraint de máquina de estados no banco — transições inválidas são possíveis via UPDATE direto.

**Sugestão:** Adicionar trigger que valide a sequência de transições.

---

### RULE-08 — Histórico de status auditado automaticamente

**Onde:** Trigger `trg_levantamento_item_status_historico` → tabela `levantamento_item_status_historico`

**Regra:** Cada mudança de `status_atendimento` é registrada com timestamp, ação anterior/nova e quem alterou.

**Status:** ✅ Implementado. Auditoria completa para fins legais e operacionais.

---

### RULE-09 — tipo_entrada MANUAL não tem score YOLO

**Onde:** `ItemDetailPanel.tsx` e `ItemScoreBadge.tsx`

**Regra:** Itens manuais não passaram por YOLO. Exibir "Entrada manual" no lugar da barra de confiança.

**Risco:** Comparações entre itens DRONE e MANUAL usando score podem ser enganosas.

**Status:** ✅ Verificado no frontend. Nenhum CHECK constraint no banco (desnecessário — o campo pode ser null).

---

### RULE-10 — score_final: normalização obrigatória 0-1 ou 0-100

**Onde:** `normalizeScore()` em `ItemDetailPanel.tsx` e `ItemScoreBadge.tsx`

**Regra:** Pipeline Python pode gravar score como `0.87` ou `87`. Se `raw > 1`, divide por 100.

**Faixas de confiança:**

| Score normalizado | Classificação | Cor |
|------------------|---------------|-----|
| >= 0.85 | Muito alta | Vermelho |
| >= 0.65 | Alta | Laranja |
| >= 0.45 | Média | Âmbar |
| < 0.45 | Baixa | Verde |

**Risco:** Função duplicada em dois arquivos. Se uma for atualizada sem a outra, divergência.

**Sugestão:** Centralizar `normalizeScore` e `getScoreConfig` em `src/lib/scoreUtils.ts` e importar em ambos.

---

### RULE-11 — Recorrência detectada em 30 dias / 50 metros

**Onde:** Trigger `trg_levantamento_item_recorrencia` no banco

**Regra:**
1. Novo item inserido → trigger verifica se há outro item do mesmo cliente com mesmo `endereco_curto` OU coordenadas a ≤ 50m nos últimos 30 dias
2. Se recorrente (≥ 2 ocorrências):
   - Cria/atualiza `levantamento_item_recorrencia`
   - Eleva prioridade para `Urgente` (se menor)
   - Recalcula `sla_horas` com nova prioridade
   - Atualiza o `sla_operacional` recém-criado

**Status:** ✅ Implementado no banco. Operação não depende do frontend.

**Risco:** A janela de 30 dias/50m é configuração hardcoded no trigger. Sem interface para o admin ajustar.

---

### RULE-12 — SLA criado automaticamente no INSERT

**Onde:** Trigger `trg_levantamento_item_criar_sla_auto`

**Regra:** Todo item de levantamento ao ser inserido gera automaticamente um registro em `sla_operacional` com prazo calculado via `sla_resolve_config()`.

**Status:** ✅ Implementado. Garante que nenhum item fique sem SLA.

**Risco:** Se `sla_config` não existir para o cliente (seed não executado), trigger pode falhar ou usar defaults incorretos.

---

## MÓDULO: SLA

### RULE-13 — Prazos base por prioridade

**Onde:** `SLA_RULES` em `src/types/sla.ts` + `sla_config` no banco

| Prioridade | Prazo base |
|-----------|-----------|
| Crítica / Urgente | 4 horas |
| Alta | 12 horas |
| Moderada / Média | 24 horas |
| Baixa / Monitoramento | 72 horas |

**Risco:** Tabela definida em `sla.ts` (frontend) E em `sla_config` (banco). Se divergirem, o frontend mostra um prazo e o banco calcula outro.

**Sugestão:** `sla.ts` deve ser usado apenas para exibição. O prazo real é sempre o `sla_horas` calculado pelo banco.

---

### RULE-14 — Redutores de prazo climáticos

**Onde:** `calcularSlaHoras()` em `sla.ts` + `sla_aplicar_fatores()` no banco

| Condição | Redutor |
|----------|---------|
| Risco = Muito Alto | -30% |
| Persistência de chuva alta (> 3 dias) | -20% |
| Temperatura > 30°C | -10% |

**Redutores são cumulativos e somados.**

**Mínimo absoluto:** 2 horas — `Math.max(2, Math.round(horas))` no frontend e equivalente no banco.

**Risco:** Lógica duplicada em TypeScript e PL/pgSQL. Uma mudança de coeficiente precisa ser aplicada nos dois lugares.

---

### RULE-15 — Feriados e horário comercial no prazo_final

**Onde:** `sla_feriados` + `sla_calcular_prazo_final()` + `sla_config.horario_comercial`

**Regra:** Se `horario_comercial = true`, o prazo final não conta horas fora do expediente nem em feriados.

**Risco:** Feriados não cadastrados fazem o sistema tratar dias não-úteis como úteis.

**Seed disponível:** `api.slaFeriados.seedNacionais` — deve ser executado ao criar novo cliente.

---

### RULE-16 — Escalonamento preserva prioridade original

**Onde:** `escalar_sla_operacional()` RPC + campos `prioridade_original`, `escalonado`, `escalonado_em`

**Regra:** Ao escalar, grava `prioridade_original` antes de elevar. Permite reverter e auditar.

**Risco:** Múltiplos escalonamentos em cadeia — verificar se `prioridade_original` não é sobrescrita.

---

### RULE-17 — Vencimento marcado pelo banco, status visual pelo frontend

**Onde:** Edge Function `sla-marcar-vencidos` (cron 15min) + `getSlaVisualStatus()` (frontend)

**Regra:** O banco marca `status='vencido'` a cada 15 minutos. O frontend calcula o status visual em tempo real para compensar a janela de 15 minutos.

**Separação de responsabilidades:** ✅ Correto. O banco é a fonte de verdade, o frontend é o display.

---

## MÓDULO: OPERADOR DE CAMPO

### RULE-18 — Checkin GPS automático

**Onde:** `VistoriaEtapa1Responsavel.tsx` — `navigator.geolocation.getCurrentPosition`

**Regra:** Ao montar o formulário, GPS é capturado automaticamente (timeout 8s, maxAge 30s). Gravado em `lat_chegada`, `lng_chegada`, `checkin_em`.

**Risco:** GPS pode falhar silenciosamente. `checkin_em` fica null sem aviso claro ao agente.

---

### RULE-19 — 3 tentativas sem acesso → prioridade_drone automática

**Onde:** Trigger `trg_atualizar_perfil_imovel`

**Regra:** Ao inserir 3ª vistoria com `acesso_realizado=false` para o mesmo imóvel, trigger seta `prioridade_drone=true`.

**Risco:** Sem janela temporal. 3 tentativas em 6 meses têm o mesmo peso que 3 em uma semana.

**Sugestão:** Adicionar filtro de janela temporal na contagem (ex: últimos 60 dias).

---

### RULE-20 — Depósitos PNCD: focos ≤ inspecionados

**Onde:** `VistoriaEtapa3Inspecao.tsx` — validação no frontend

**Regra:** Para cada depósito (A1-E), `qtd_com_focos` não pode exceder `qtd_inspecionados`.

**Risco:** Sem CHECK constraint no banco. Insert direto pode violar.

**Sugestão:** `ADD CONSTRAINT chk_focos_inspecionados CHECK (qtd_com_focos <= qtd_inspecionados)` em `vistoria_depositos`.

---

### RULE-21 — Ciclos epidemiológicos bimestrais (1–6)

**Onde:** `Math.ceil((new Date().getMonth() + 1) / 2)` no frontend

**Regra:** Ano dividido em 6 ciclos de 2 meses cada. Ciclo atual calculado no momento da criação da vistoria.

**Risco:** Lógica apenas no frontend. Sem coluna calculada no banco. Se o ciclo for recalculado retroativamente, pode divergir do momento da criação.

**Sugestão:** Persistir `ciclo_calculado` no momento da criação (já é persistido no campo `ciclo` da vistoria — verificar se é sempre gravado corretamente).

---

## MÓDULO: CRUZAMENTO CASO↔FOCO

### RULE-22 — Cruzamento exclusivamente via trigger

**Onde:** Trigger `trg_cruzar_caso_focos` → `fn_cruzar_caso_com_focos`

**Regra (CRÍTICA):** O cruzamento entre casos notificados e focos de levantamento é feito EXCLUSIVAMENTE pelo trigger no banco. `caso_foco_cruzamento` NUNCA deve ser inserido manualmente.

**Status:** ✅ Documentado em CLAUDE.md como regra imutável.

---

### RULE-23 — Raio de 300m para cruzamento e alerta

**Onde:** Trigger + `ItemDetailPanel.tsx`

**Regra:** Focos em 300m de um caso notificado têm prioridade elevada para Crítico.

**Risco:** Payload JSONB do item é sobrescrito com apenas o último `caso_id`. Múltiplos casos próximos perdem dados.

**Sugestão urgente:** Usar `jsonb_set` para acumular array de caso_ids no payload.

---

### RULE-24 — Raio de 500m para sugestão de planejamento

**Onde:** `AdminCasosNotificados.tsx` — lógica no frontend

**Regra:** 3+ casos no mesmo bairro em 500m → botão "Criar planejamento" para o gestor.

**Risco:** Lógica de clustering apenas no frontend, sem persistência.

---

### RULE-25 — LGPD em casos_notificados

**Onde:** Estrutura da tabela `casos_notificados` + CLAUDE.md regra crítica

**Regra (CRÍTICA):** SEM nome, CPF, data de nascimento ou qualquer identificador direto do paciente.

**Status:** ✅ Estrutura da tabela não tem colunas PII. Mas integrações futuras com e-SUS devem ser revisadas.

---

## MÓDULO: MULTITENANCY

### RULE-26 — Todo select/insert/update filtrado por cliente_id

**Onde:** RLS no banco + `.eq('cliente_id', clienteId)` em api.ts + `useClienteAtivo` hook

**Regra (CRÍTICA):** Sem exceção. Qualquer query sem `cliente_id` pode vazar dados entre prefeituras.

**Status:** ✅ RLS como rede de segurança. api.ts como filtro adicional.

---

### RULE-27 — clienteId obtido SEMPRE via useClienteAtivo

**Onde:** `src/hooks/useClienteAtivo.tsx`

**Regra:** Em componentes e hooks, nunca derivar `clienteId` por outra via.

**Status:** ✅ Padrão estabelecido. Risco de desvio em novos desenvolvimentos.

---

## Resumo de regras por nível de risco

| Regra | Nível | Status |
|-------|-------|--------|
| Cruzamento caso↔foco somente via trigger | CRÍTICO | ✅ |
| LGPD em casos_notificados | CRÍTICO | ✅ |
| Multitenancy por cliente_id | CRÍTICO | ✅ |
| Credenciais Cloudinary via Edge Function | CRÍTICO | ✅ |
| Score YOLO normalizado | ALTO | ⚠️ Duplicado |
| SLA_RULES duplicado em sla.ts e banco | ALTO | ⚠️ Risco de divergência |
| Payload JSONB sobrescrito (múltiplos casos) | ALTO | ❌ Bug |
| Validação de depósitos sem CHECK no banco | MÉDIO | ⚠️ Apenas frontend |
| Quota de voos sem check no backend | MÉDIO | ⚠️ Apenas frontend |
| Rate limiting no canal cidadão | MÉDIO | ❌ Ausente |
| Ciclo epidemiológico apenas no frontend | BAIXO | ⚠️ Risco retroativo |
| Janela temporal na regra de 3 tentativas | BAIXO | ⚠️ Sem janela |

---

## Dúvidas em aberto

- Existe lógica de negócio em Edge Functions que não está documentada aqui?
- O campo `sla_horas` em `levantamento_itens` é sempre calculado pelo banco ou pode ser sobrescrito pelo frontend?
- A normalização de score YOLO é feita apenas no frontend ou também antes de gravar no banco?
