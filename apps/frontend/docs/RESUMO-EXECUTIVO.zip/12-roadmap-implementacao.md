# 12 — Roadmap de Implementação

## Objetivo deste documento

Apresentar um plano incremental, seguro e realista de implementação das melhorias identificadas, organizado em etapas que não quebram funcionalidades existentes.

---

## Princípios do roadmap

1. **Primeiro corrigir, depois evoluir** — bugs e riscos antes de novas features
2. **Incrementalidade** — cada etapa entrega valor isolado
3. **Segurança de regressão** — mudanças estruturais (refatorações) depois de testes estabelecidos
4. **Quick wins primeiro** — melhorias de alto impacto e baixo esforço no início
5. **Não reescrever o que funciona** — evoluir, não destruir

---

## Etapa 0 — Análise e estabilização (Semana 1-2)

**Objetivo:** Entender o estado atual e corrigir os riscos mais urgentes sem tocar em funcionalidades.

### 0.1 — Auditoria de credenciais do pipeline Python

- Identificar qual chave o pipeline Python usa para acessar o Supabase
- Se `service_role`: criar usuário de serviço com permissões mínimas
- Documentar em `docs/06-rls-e-seguranca.md`

**Responsável:** Arquiteto/Backend
**Esforço:** P-M
**Risco:** Baixo

---

### 0.2 — Corrigir trigger de payload JSONB (Bug M-01)

```sql
-- Migration: 20260326_fix_payload_casos_proximos.sql
-- Substituir sobrescrita por acumulação em array
```

**Responsável:** Backend/DBA
**Esforço:** P
**Risco:** Baixo

---

### 0.3 — Atualizar schema.sql

```bash
supabase db dump --schema > schema.sql
git add schema.sql && git commit -m "chore: sync schema.sql with current migrations"
```

**Responsável:** Qualquer dev
**Esforço:** P
**Risco:** Zero

---

### 0.4 — Verificar RLS em tabelas recentes

Checar e documentar RLS de: `yolo_feedback`, `levantamento_analise_ia`, `unidades_saude_sync_controle`, `unidades_saude_sync_log`, `cliente_integracoes`.

**Responsável:** Backend
**Esforço:** P
**Risco:** Zero (só leitura inicialmente)

---

## Etapa 1 — Quick wins de segurança e qualidade (Semana 2-3)

**Objetivo:** Fechar as brechas de segurança e qualidade de dados de menor esforço.

### 1.1 — RoleGuard nas rotas admin (M-05)

```typescript
// src/components/RoleGuard.tsx
// App.tsx: envolver todas as rotas /admin/* com RoleGuard
```

**Esforço:** P | **Risco:** Baixo

---

### 1.2 — CHECK constraint em vistoria_depositos (M-03)

```sql
ALTER TABLE vistoria_depositos
ADD CONSTRAINT chk_focos_nao_excedem_inspecionados
CHECK (qtd_com_focos <= qtd_inspecionados);
```

**Esforço:** P | **Risco:** Baixo

---

### 1.3 — Centralizar normalizeScore (M-04)

- Criar `src/lib/scoreUtils.ts`
- Atualizar imports em `ItemDetailPanel.tsx` e `ItemScoreBadge.tsx`

**Esforço:** P | **Risco:** Baixo

---

### 1.4 — Janela temporal na regra de 3 tentativas (M-13)

```sql
-- Atualizar trigger trg_atualizar_perfil_imovel para considerar apenas 60 dias
```

**Esforço:** P | **Risco:** Baixo

---

### 1.5 — Remover/arquivar migration de seed de usuário dev (DT-08)

- Verificar se usuário existe em produção
- Se sim: desativar ou remover
- Documentar que seeds de dev não devem ir para repositório principal

**Esforço:** P | **Risco:** Baixo

---

## Etapa 2 — Visibilidade operacional (Semana 3-5)

**Objetivo:** Dar ao gestor visibilidade sobre o que está acontecendo no sistema (pipeline, CNES, erros).

### 2.1 — Status de processamento do pipeline (M-06)

**Migration:**
```sql
ALTER TABLE levantamentos
ADD COLUMN status_processamento text DEFAULT 'aguardando'
  CHECK (status_processamento IN ('aguardando', 'processando', 'concluido', 'erro')),
ADD COLUMN processamento_erro text,
ADD COLUMN processamento_em timestamptz;
```

**Pipeline Python:** Atualizar para setar `status_processamento` ao início e fim.

**Frontend:** Badge de status em `AdminPlanejamentos.tsx` e na listagem de levantamentos.

**Esforço:** M | **Risco:** Baixo

---

### 2.2 — Notificação de falha no CNES Sync (M adaptado)

Na Edge Function `cnes-sync`, ao esgotar retries, enviar email via Resend para o admin do cliente.

**Esforço:** P | **Risco:** Baixo

---

### 2.3 — Rate limiting no Canal Cidadão (M-08)

```typescript
// Em Edge Function ou RPC canal_cidadao
// Verificar IP hash nos últimos 60 minutos
```

**Esforço:** M | **Risco:** Baixo

---

## Etapa 3 — Qualidade de dados e banco (Semana 5-7)

**Objetivo:** Fortalecer as invariantes de negócio no banco de dados.

### 3.1 — Habilitar PostGIS e migrar cruzamento geoespacial (M-11)

**Verificar primeiro:** `SELECT * FROM pg_extension WHERE extname = 'postgis';`

Se disponível:
```sql
CREATE EXTENSION IF NOT EXISTS postgis;

ALTER TABLE levantamento_itens
ADD COLUMN geom geography(POINT, 4326)
GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)) STORED;

CREATE INDEX idx_levantamento_itens_geom ON levantamento_itens USING GIST (geom);

-- Atualizar fn_cruzar_caso_com_focos para usar ST_DWithin
```

**Esforço:** M | **Risco:** Médio (alterar trigger crítico — testar exaustivamente)

---

### 3.2 — Migrar casos_notificados para PostGIS também

```sql
ALTER TABLE casos_notificados
ADD COLUMN geom geography(POINT, 4326)
GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)) STORED;

CREATE INDEX idx_casos_notificados_geom ON casos_notificados USING GIST (geom);
```

**Esforço:** P | **Risco:** Baixo (coluna gerada, sem trigger)

---

### 3.3 — RPC dashboard_summary (M-12)

Criar RPC que retorna todos os KPIs do dashboard em uma única query.

**Esforço:** M | **Risco:** Baixo (nova RPC, sem alterar existentes)

---

## Etapa 4 — Testes e confiabilidade (Semana 7-10)

**Objetivo:** Criar rede de segurança para evoluções futuras sem medo de regressão.

### 4.1 — Testes unitários (Vitest)

```
src/__tests__/
├── sla.test.ts          # calcularSlaHoras, getSlaVisualStatus
├── scoreUtils.test.ts   # normalizeScore, getScoreConfig
├── ciclo.test.ts        # lógica de ciclos epidemiológicos
└── geo.test.ts          # distâncias, bounding box
```

**Esforço:** M | **Risco:** Zero

---

### 4.2 — Testes de banco (pgTAP ou scripts SQL)

```sql
-- Testes para:
-- 1. Trigger SLA automático ao inserir levantamento_item
-- 2. Trigger de recorrência (eleva prioridade)
-- 3. Trigger de cruzamento caso↔foco
-- 4. Constraint de 1 levantamento por dia
-- 5. Isolamento RLS entre clientes
```

**Esforço:** G | **Risco:** Zero (testes, não produção)

---

### 4.3 — Testes E2E principais (Playwright)

```
e2e/
├── auth.spec.ts           # Login, logout, papel
├── operador.spec.ts       # Fluxo de atendimento completo
├── vistoria.spec.ts       # Fluxo de vistoria offline/online
├── multitenancy.spec.ts   # Isolamento entre prefeituras
└── sla.spec.ts            # Criação automática, vencimento, escalamento
```

**Esforço:** G | **Risco:** Zero

---

## Etapa 5 — Refatoração estrutural (Semana 10-14)

**Objetivo:** Reduzir dívida técnica estrutural, com rede de segurança de testes já estabelecida.

### 5.1 — Dividir api.ts em módulos (M-09)

**Sequência segura:**
1. Criar pasta `src/services/api/`
2. Mover namespace `sla` → `api/sla.ts` (testar)
3. Mover namespace `levantamentos` → `api/levantamentos.ts` (testar)
4. Continuar módulo por módulo
5. `api/index.ts` re-exporta objeto `api` unificado
6. `services/api.ts` re-exporta de `api/index.ts` (compatibilidade)

**Esforço:** G | **Risco:** Médio (requer testes antes)

---

### 5.2 — Dividir database.ts em módulos (M-15)

Similar ao 5.1 para tipos TypeScript.

**Esforço:** M | **Risco:** Baixo

---

### 5.3 — ESLint rules customizadas (M-14)

```javascript
// .eslintrc.js — regras customizadas
rules: {
  'no-restricted-imports': ['error', {
    paths: [{ name: '@/lib/supabase', message: 'Use api.ts instead' }]
  }]
}
```

**Esforço:** M | **Risco:** Zero

---

## Etapa 6 — Evolução de produto (Semana 14+)

**Objetivo:** Novas funcionalidades com a base saneada.

### 6.1 — Wizard de onboarding de novo cliente

Formulário passo-a-passo para configurar uma nova prefeitura:
1. Dados básicos (nome, CNPJ, IBGE)
2. Regiões/bairros (import CSV ou cadastro manual)
3. Configuração de SLA
4. Seeds automáticos (já implementados)
5. Convite de usuários

### 6.2 — API pública para integração municipal

Endpoints REST autenticados para sistemas municipais consultarem dados do Sentinella.

### 6.3 — Dashboard público de transparência

Página pública por município mostrando: focos identificados, resolvidos, tempo médio de atendimento.

### 6.4 — App mobile nativo (React Native / Expo)

Para superar limitações do PWA no iOS.

---

## Cronograma resumido

| Etapa | Período | Foco |
|-------|---------|------|
| 0 — Estabilização | Sem 1-2 | Bugs críticos, credenciais, schema |
| 1 — Quick wins | Sem 2-3 | Segurança, qualidade, constraints |
| 2 — Visibilidade | Sem 3-5 | Pipeline status, CNES, rate limiting |
| 3 — Banco | Sem 5-7 | PostGIS, RPC dashboard |
| 4 — Testes | Sem 7-10 | Unitários, banco, E2E |
| 5 — Refatoração | Sem 10-14 | api.ts, types, ESLint |
| 6 — Produto | Sem 14+ | Novas features |

---

## Regras para este roadmap

1. **Etapa 0-2:** Podem ser feitas sem testes — são correções pontuais e migrations aditivas
2. **Etapa 3 (PostGIS):** Requer testes manuais exaustivos antes de ir para produção
3. **Etapa 4:** Deve preceder qualquer refatoração grande (Etapa 5)
4. **Etapa 5:** Fazer modulo por módulo, não tudo de uma vez
5. **Etapa 6:** Apenas após etapas 0-4 completas

---

## O que NÃO está neste roadmap

- Reescrita completa do sistema
- Migração para outro banco de dados
- Troca de framework (React → outro)
- Migração para backend próprio (NestJS/etc) — ver `project_migration_nestjs.md` para esse plano separado
