# 06 — RLS e Segurança

## Objetivo deste documento

Analisar as políticas de Row Level Security (RLS) do banco de dados, o modelo de controle de acesso (RBAC), as práticas de segurança implementadas e as vulnerabilidades identificadas.

---

## Modelo de segurança geral

O Sentinella implementa **segurança em profundidade** com múltiplas camadas:

```
┌──────────────────────────────────────────────────────────┐
│ CAMADA 1: Autenticação (Supabase Auth / JWT)             │
│   - Login com email/senha gerenciado pelo Supabase       │
│   - JWT token com sub = auth.uid()                       │
└────────────────────────────────┬─────────────────────────┘
                                 │
┌────────────────────────────────▼─────────────────────────┐
│ CAMADA 2: RBAC — Papel do usuário                        │
│   - RPC get_meu_papel() → admin | supervisor | usuario   │
│     | operador                                           │
│   - Papel armazenado em tabela papeis_usuarios           │
└────────────────────────────────┬─────────────────────────┘
                                 │
┌────────────────────────────────▼─────────────────────────┐
│ CAMADA 3: RLS — Row Level Security no PostgreSQL         │
│   - Toda tabela com RLS habilitado                       │
│   - Políticas filtram por cliente_id via auth.uid()      │
└────────────────────────────────┬─────────────────────────┘
                                 │
┌────────────────────────────────▼─────────────────────────┐
│ CAMADA 4: Filtros em api.ts                              │
│   - Toda query filtra por .eq('cliente_id', clienteId)   │
│   - Dupla proteção além do RLS                           │
└──────────────────────────────────────────────────────────┘
```

---

## RLS — Como funciona

Row Level Security é uma funcionalidade do PostgreSQL que permite definir quais linhas cada usuário pode ver/modificar.

### Padrão de política usado no sistema

```sql
-- Habilitar RLS
ALTER TABLE nome_tabela ENABLE ROW LEVEL SECURITY;

-- Política de isolamento por cliente
CREATE POLICY "isolamento_por_cliente" ON nome_tabela
  USING (
    cliente_id IN (
      SELECT cliente_id FROM usuarios
      WHERE auth_id = auth.uid()
    )
  );
```

**Como funciona:** Quando um usuário faz uma query, o banco automaticamente adiciona a condição da política. O usuário só vê linhas onde `cliente_id` está na lista de clientes que ele acessa.

### Variações de política usadas

**1. Isolamento por cliente (padrão)**
```sql
USING (cliente_id IN (SELECT cliente_id FROM usuarios WHERE auth_id = auth.uid()))
```

**2. Acesso por papel (ex: operador só vê seus SLAs)**
```sql
USING (
  cliente_id IN (SELECT cliente_id FROM usuarios WHERE auth_id = auth.uid())
  AND (
    papel = 'admin'
    OR atribuido_a = auth.uid()
  )
)
```

**3. Acesso público (ex: canal cidadão)**
```sql
-- Tabela canal_cidadao usa SECURITY DEFINER RPC
-- Inserts via RPC sem autenticação do usuário
```

**4. Sem RLS — tabelas de seed/config global**
Tabelas de configuração global (ex: `sentinela_yolo_class_config`) podem ter políticas mais permissivas para leitura do pipeline Python.

---

## RBAC — Controle de acesso por papel

### Papéis definidos

| Papel | Escopo | Permissões |
|-------|--------|-----------|
| `admin` | Plataforma | Acesso total; pode trocar de cliente |
| `supervisor` | Cliente | Admin do cliente; CRUD completo |
| `usuario` | Cliente | Leitura + operações básicas |
| `operador` | Cliente | Portal `/operador/*`; apenas seus itens |

### Como o papel é verificado

```typescript
// Hook useClienteAtivo.tsx
const papel = await supabase.rpc('get_meu_papel');
```

```sql
-- Função RPC get_meu_papel()
CREATE OR REPLACE FUNCTION get_meu_papel()
RETURNS text AS $$
  SELECT papel FROM papeis_usuarios
  WHERE auth_id = auth.uid()
  AND cliente_id = current_setting('app.cliente_id', true)::uuid
$$ LANGUAGE sql SECURITY DEFINER;
```

**Problema identificado:** O frontend verifica o papel para controlar navegação (quais rotas mostrar), mas sem middleware de rota que impeça acesso direto via URL a rotas restritas.

---

## Segurança de credenciais

### O que está correto

| Credencial | Onde fica | Como é usada |
|-----------|-----------|--------------|
| Cloudinary API Key | Edge Function (servidor) | Upload/delete de imagens |
| Resend API Key | Edge Function | Envio de emails |
| CNES API Key | Edge Function | Sync de unidades |
| Supabase Service Key | Edge Function | Operações admin no banco |
| Supabase Anon Key | Frontend (pública) | Queries autenticadas via RLS |

**A `anon key` do Supabase é intencionalmente pública.** O RLS garante que, mesmo com ela, um usuário só vê seus dados.

### Potenciais riscos de credenciais

1. **Pipeline Python** acessa Supabase com que tipo de credencial? Se usar `service_role`, bypassa RLS.
2. **Variáveis de ambiente** no build Vite — qualquer `VITE_*` fica exposta no bundle do browser.

---

## LGPD — Conformidade

### O que o sistema faz corretamente

1. **`casos_notificados`** não armazena nome, CPF, data de nascimento — apenas endereço, bairro, doença
2. **Canal cidadão** — denúncia sem dados pessoais do denunciante
3. **Upload de imagens** — sem reconhecimento facial implementado

### Pontos de atenção

1. **Integração e-SUS Notifica** — o payload enviado ao e-SUS pode conter dados pessoais? `montarPayloadESUS()` em `sinan.ts` deve ser revisado
2. **Fotos de imóveis** (`foto_externa_url`) — a foto pode capturar moradores sem consentimento
3. **GPS de agentes** (`lat_chegada`, `lng_chegada`) — rastreamento de localização dos agentes; necessário consentimento documentado
4. **Vistoria de sintomas** — mesmo sem nome, a combinação endereço + sintomas + data pode ser quasi-identificadora

---

## Análise de migrations de RLS

### Migration `20250302100000_rls_geral_todas_tabelas.sql`

Aplicou RLS em "todas as tabelas". Porém, migrations posteriores adicionaram novas tabelas — nem sempre com RLS explicitamente configurado.

**Tabelas de migrations recentes que devem ter RLS verificado:**

| Tabela | Migration | RLS verificado? |
|--------|-----------|----------------|
| `canal_cidadao` | 20250317001000 | Usa RPC SECURITY DEFINER (correto) |
| `yolo_feedback` | 20250317002000 | Precisa verificar |
| `levantamento_analise_ia` | 20250317002000 | Precisa verificar |
| `imoveis` | 20250318001000 | Sim (mencionado em CLAUDE.md) |
| `vistorias` | 20250318001000 | Sim |
| `vistoria_depositos` | 20250318001000 | Sim |
| `casos_notificados` | 20250318000000 | Sim |
| `caso_foco_cruzamento` | 20250318000000 | Sim |
| `unidades_saude` | 20250318000000 | Sim |
| `unidades_saude_sync_controle` | 20250319000000 | Precisa verificar |
| `unidades_saude_sync_log` | 20250319000000 | Precisa verificar |
| `cliente_integracoes` | sprint 4 | Precisa verificar |
| `item_notificacoes_esus` | sprint 4 | Sim (mencionado em CLAUDE.md) |

---

## Canal Cidadão — Segurança especial

A rota `/denuncia/:slug/:bairroId` é completamente pública — sem autenticação.

**Como é protegida:**
- Página usa `slug` do cliente (não o `id` direto) para identificar a prefeitura
- Inserção via RPC `SECURITY DEFINER` que bypassa RLS de forma controlada
- RPC valida o `slug` antes de inserir
- Sem possibilidade de ler dados de outros clientes

**Risco:** A RPC de denúncia poderia ser chamada em loop para spam de denúncias. Sem rate limiting implementado.

---

## Acesso do pipeline Python

O pipeline externo em Python precisa:
1. Ler `sentinela_yolo_class_config` e `sentinela_drone_risk_config`
2. Inserir em `levantamento_itens` via RPC
3. Fazer upload no Cloudinary via Edge Function

**Questão crítica:** Com que chave o pipeline acessa o Supabase?
- Se `service_role` key → bypassa RLS → pode ler/escrever qualquer dado de qualquer cliente
- Se `anon` key com usuário autenticado → sujeito ao RLS (mais seguro)

A documentação não especifica claramente. Isso é um ponto de risco a ser investigado.

---

## Pontos fortes de segurança

1. **RLS como segunda linha de defesa** — mesmo se api.ts falhar em filtrar, o banco protege
2. **Credenciais sensíveis somente em Edge Functions** — Cloudinary, Resend, CNES
3. **LGPD respeitada em `casos_notificados`** — sem dados pessoais identificáveis
4. **Canal cidadão isolado** — RPC SECURITY DEFINER controlada
5. **Auditoria de SLA config** — qualquer mudança registrada em `sla_config_audit`
6. **Histórico de status de itens** — auditoria via trigger `trg_levantamento_item_status_historico`

---

## Problemas de segurança identificados

### S1 — Verificação de papel apenas no frontend (ALTO)

O papel do usuário (`admin`, `supervisor`, etc.) é verificado no frontend para controle de navegação, mas não há middleware que impeça acesso a rotas via URL direta. Um usuário operador poderia acessar `/admin/clientes` digitando a URL.

**Mitigação parcial:** As queries protegidas por RLS retornariam dados vazios ou erro. Mas a tela em si seria renderizada.

**Sugestão:** Adicionar componente de guarda de rota que verifique papel antes de renderizar a página.

### S2 — Sem rate limiting no Canal Cidadão (MÉDIO)

A rota pública de denúncia poderia ser abusada para inserir spam de registros.

**Sugestão:** Adicionar rate limiting na Edge Function ou na RPC (por IP ou por `slug`).

### S3 — Credenciais do pipeline Python não especificadas (ALTO)

Se o pipeline Python usa `service_role` key, tem acesso irrestrito a todos os dados de todos os clientes.

**Sugestão:** Criar usuário de serviço com papel específico e RLS restrito ao pipeline.

### S4 — Variáveis de ambiente no build (BAIXO)

Qualquer variável `VITE_*` fica exposta no bundle do browser. Verificar se há variáveis sensíveis com prefix `VITE_`.

### S5 — RLS não verificado em tabelas recentes (MÉDIO)

Tabelas adicionadas nas últimas migrations precisam de auditoria explícita de RLS.

---

## Checklist de auditoria de segurança

- [ ] Verificar RLS em todas as tabelas após migration 20250317
- [ ] Auditar credenciais do pipeline Python (service_role vs. usuário com papel)
- [ ] Implementar guarda de rota por papel no frontend
- [ ] Adicionar rate limiting no canal cidadão
- [ ] Revisar payload do e-SUS para compliance LGPD
- [ ] Verificar variáveis `VITE_*` no `.env` de produção
- [ ] Confirmar que `service_role` key não está exposta no frontend
- [ ] Revisar RPC SECURITY DEFINER — cada uma está fazendo o mínimo necessário?

---

## Dúvidas em aberto

- O pipeline Python usa `service_role` ou uma chave de usuário com papel restrito?
- Existe política de rotação de credenciais (Cloudinary, Resend, e-SUS)?
- As Edge Functions têm seus próprios secrets isolados ou compartilham?
- Existe CORS configurado nas Edge Functions para aceitar apenas origens conhecidas?
- Há monitoramento de tentativas de acesso não autorizado?
